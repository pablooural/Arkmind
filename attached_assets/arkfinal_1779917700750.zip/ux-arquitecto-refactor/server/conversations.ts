/**
 * Conversations API Routes
 * Gestiona CRUD de conversaciones y mensajes por nodo
 */

import { Router } from "express";
import { supabase, DbConversation, DbMessage, handleSupabaseError } from "./supabase.js";

const router = Router();

/**
 * GET /api/conversations/:projectId
 * Obtener todas las conversaciones de un proyecto
 */
router.get("/:projectId", async (req, res) => {
  try {
    const userId = req.headers["x-user-id"] as string;
    const { projectId } = req.params;

    if (!userId) {
      return res.status(401).json({ error: "Usuario no autenticado" });
    }

    // Verificar que el proyecto pertenece al usuario
    const { data: project, error: projectError } = await supabase
      .from("projects")
      .select("user_id")
      .eq("id", projectId)
      .single();

    if (projectError || project?.user_id !== userId) {
      return res.status(403).json({ error: "No tienes permiso para acceder a este proyecto" });
    }

    const { data, error } = await supabase
      .from("conversations")
      .select("*")
      .eq("project_id", projectId)
      .order("created_at", { ascending: false });

    if (error) {
      throw error;
    }

    res.json({ conversations: data });
  } catch (error) {
    console.error("Error en GET /api/conversations/:projectId:", error);
    res.status(500).json({ error: handleSupabaseError(error) });
  }
});

/**
 * GET /api/conversations/:projectId/:nodePath
 * Obtener conversación de un nodo específico
 */
router.get("/:projectId/:nodePath", async (req, res) => {
  try {
    const userId = req.headers["x-user-id"] as string;
    const { projectId, nodePath } = req.params;

    if (!userId) {
      return res.status(401).json({ error: "Usuario no autenticado" });
    }

    // Verificar que el proyecto pertenece al usuario
    const { data: project, error: projectError } = await supabase
      .from("projects")
      .select("user_id")
      .eq("id", projectId)
      .single();

    if (projectError || project?.user_id !== userId) {
      return res.status(403).json({ error: "No tienes permiso para acceder a este proyecto" });
    }

    const { data, error } = await supabase
      .from("conversations")
      .select("*")
      .eq("project_id", projectId)
      .eq("node_path", decodeURIComponent(nodePath))
      .single();

    if (error) {
      if (error.code === "PGRST116") {
        return res.status(404).json({ error: "Conversación no encontrada" });
      }
      throw error;
    }

    res.json({ conversation: data });
  } catch (error) {
    console.error("Error en GET /api/conversations/:projectId/:nodePath:", error);
    res.status(500).json({ error: handleSupabaseError(error) });
  }
});

/**
 * POST /api/conversations/:projectId
 * Crear una nueva conversación
 */
router.post("/:projectId", async (req, res) => {
  try {
    const userId = req.headers["x-user-id"] as string;
    const { projectId } = req.params;
    const { node_path, goal } = req.body;

    if (!userId) {
      return res.status(401).json({ error: "Usuario no autenticado" });
    }

    if (!node_path) {
      return res.status(400).json({ error: "node_path requerido" });
    }

    // Verificar que el proyecto pertenece al usuario
    const { data: project, error: projectError } = await supabase
      .from("projects")
      .select("user_id")
      .eq("id", projectId)
      .single();

    if (projectError || project?.user_id !== userId) {
      return res.status(403).json({ error: "No tienes permiso para acceder a este proyecto" });
    }

    const { data, error } = await supabase
      .from("conversations")
      .insert({
        project_id: projectId,
        node_path,
        goal: goal || null,
      })
      .select()
      .single();

    if (error) {
      throw error;
    }

    res.status(201).json({ conversation: data });
  } catch (error) {
    console.error("Error en POST /api/conversations/:projectId:", error);
    res.status(500).json({ error: handleSupabaseError(error) });
  }
});

/**
 * GET /api/conversations/:conversationId/messages
 * Obtener todos los mensajes de una conversación
 */
router.get("/:conversationId/messages", async (req, res) => {
  try {
    const userId = req.headers["x-user-id"] as string;
    const { conversationId } = req.params;

    if (!userId) {
      return res.status(401).json({ error: "Usuario no autenticado" });
    }

    // Verificar que la conversación pertenece a un proyecto del usuario
    const { data: conversation, error: convError } = await supabase
      .from("conversations")
      .select("project_id")
      .eq("id", conversationId)
      .single();

    if (convError) {
      return res.status(404).json({ error: "Conversación no encontrada" });
    }

    const { data: project, error: projectError } = await supabase
      .from("projects")
      .select("user_id")
      .eq("id", conversation.project_id)
      .single();

    if (projectError || project?.user_id !== userId) {
      return res.status(403).json({ error: "No tienes permiso para acceder a esta conversación" });
    }

    const { data, error } = await supabase
      .from("messages")
      .select("*")
      .eq("conversation_id", conversationId)
      .order("created_at", { ascending: true });

    if (error) {
      throw error;
    }

    res.json({ messages: data });
  } catch (error) {
    console.error("Error en GET /api/conversations/:conversationId/messages:", error);
    res.status(500).json({ error: handleSupabaseError(error) });
  }
});

/**
 * POST /api/conversations/:conversationId/messages
 * Agregar un mensaje a una conversación
 */
router.post("/:conversationId/messages", async (req, res) => {
  try {
    const userId = req.headers["x-user-id"] as string;
    const { conversationId } = req.params;
    const { role, content, message_type } = req.body;

    if (!userId) {
      return res.status(401).json({ error: "Usuario no autenticado" });
    }

    if (!role || !content) {
      return res.status(400).json({ error: "role y content requeridos" });
    }

    // Verificar que la conversación pertenece a un proyecto del usuario
    const { data: conversation, error: convError } = await supabase
      .from("conversations")
      .select("project_id")
      .eq("id", conversationId)
      .single();

    if (convError) {
      return res.status(404).json({ error: "Conversación no encontrada" });
    }

    const { data: project, error: projectError } = await supabase
      .from("projects")
      .select("user_id")
      .eq("id", conversation.project_id)
      .single();

    if (projectError || project?.user_id !== userId) {
      return res.status(403).json({ error: "No tienes permiso para acceder a esta conversación" });
    }

    const { data, error } = await supabase
      .from("messages")
      .insert({
        conversation_id: conversationId,
        role,
        content,
        message_type: message_type || null,
      })
      .select()
      .single();

    if (error) {
      throw error;
    }

    res.status(201).json({ message: data });
  } catch (error) {
    console.error("Error en POST /api/conversations/:conversationId/messages:", error);
    res.status(500).json({ error: handleSupabaseError(error) });
  }
});

export default router;
