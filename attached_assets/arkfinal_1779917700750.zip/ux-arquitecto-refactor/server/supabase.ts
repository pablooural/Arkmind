/**
 * Supabase Client Service
 * Gestiona conexión con Supabase para proyectos, conversaciones, etc.
 */

import { createClient } from "@supabase/supabase-js";

const supabaseUrl = process.env.SUPABASE_URL || "";
const supabaseKey = process.env.SUPABASE_API_KEY || "";

if (!supabaseUrl || !supabaseKey) {
  console.warn("⚠️  SUPABASE_URL o SUPABASE_API_KEY no configurados");
}

export const supabase = createClient(supabaseUrl, supabaseKey);

/**
 * Tipos de datos para Supabase
 */

export interface DbUser {
  id: string;
  email: string;
  name: string;
  created_at: string;
  confirmed_at: string | null;
  last_login: string | null;
  is_active: boolean;
}

export interface DbProject {
  id: string;
  user_id: string;
  name: string;
  description: string | null;
  root_path: string | null;
  created_at: string;
  updated_at: string;
  is_archived: boolean;
}

export interface DbConversation {
  id: string;
  project_id: string;
  node_path: string;
  goal: string | null;
  created_at: string;
  updated_at: string;
}

export interface DbMessage {
  id: string;
  conversation_id: string;
  role: "user" | "assistant";
  content: string;
  message_type: string | null;
  created_at: string;
}

export interface DbSnapshot {
  id: string;
  project_id: string;
  workspace_state: Record<string, unknown>;
  total_size: number | null;
  created_at: string;
  description: string | null;
}

/**
 * Helper para manejo de errores
 */
export function handleSupabaseError(error: unknown): string {
  if (error instanceof Error) {
    return error.message;
  }
  return "Error desconocido en Supabase";
}

/**
 * Verificar conexión
 */
export async function testConnection(): Promise<boolean> {
  try {
    const { data, error } = await supabase.from("users").select("count", { count: "exact" });
    if (error) {
      console.error("❌ Error conectando a Supabase:", error.message);
      return false;
    }
    console.log("✓ Conectado a Supabase");
    return true;
  } catch (error) {
    console.error("❌ Error en testConnection:", error);
    return false;
  }
}
