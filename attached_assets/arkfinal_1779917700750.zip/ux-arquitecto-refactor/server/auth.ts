/**
 * Email Authentication Service
 * Gestiona autenticación por email con confirmación
 * 
 * Endpoints:
 * POST /api/auth/send-confirmation - Enviar email de confirmación
 * POST /api/auth/confirm-email - Confirmar email y crear sesión
 */

import { Router } from "express";
import crypto from "crypto";

const router = Router();

// TODO: Configurar servicio de email (SendGrid, Resend, etc.)
// Por ahora, simulamos el envío

interface PendingConfirmation {
  email: string;
  token: string;
  expiresAt: number;
}

// Almacenar confirmaciones pendientes en memoria
// En producción, usar base de datos
const pendingConfirmations = new Map<string, PendingConfirmation>();

/**
 * POST /api/auth/send-confirmation
 * Enviar email de confirmación
 */
router.post("/send-confirmation", (req, res) => {
  try {
    const { email } = req.body;

    if (!email || typeof email !== "string") {
      return res.status(400).json({ error: "Email requerido" });
    }

    // Validar formato de email
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      return res.status(400).json({ error: "Email inválido" });
    }

    // Generar token de confirmación
    const token = crypto.randomBytes(32).toString("hex");
    const expiresAt = Date.now() + 24 * 60 * 60 * 1000; // 24 horas

    // Guardar confirmación pendiente
    pendingConfirmations.set(token, {
      email,
      token,
      expiresAt,
    });

    // TODO: Enviar email con enlace de confirmación
    // const confirmationLink = `${process.env.FRONTEND_URL}/login?token=${token}`;
    // await sendEmail(email, confirmationLink);

    // Por ahora, solo loguear
    console.log(`✓ Email de confirmación generado para: ${email}`);
    console.log(`  Token: ${token}`);
    console.log(`  Enlace: /login?token=${token}`);

    res.json({
      message: "Email de confirmación enviado",
      // En desarrollo, devolver el token para testing
      ...(process.env.NODE_ENV === "development" && { token }),
    });
  } catch (error) {
    console.error("Error en /api/auth/send-confirmation:", error);
    res.status(500).json({ error: "Error enviando email" });
  }
});

/**
 * POST /api/auth/confirm-email
 * Confirmar email y crear sesión
 */
router.post("/confirm-email", (req, res) => {
  try {
    const { token } = req.body;

    if (!token || typeof token !== "string") {
      return res.status(400).json({ error: "Token requerido" });
    }

    // Buscar confirmación pendiente
    const confirmation = pendingConfirmations.get(token);

    if (!confirmation) {
      return res.status(400).json({ error: "Token inválido o expirado" });
    }

    // Validar que no haya expirado
    if (confirmation.expiresAt < Date.now()) {
      pendingConfirmations.delete(token);
      return res.status(400).json({ error: "Token expirado" });
    }

    // Crear sesión
    const userId = `user_${Date.now()}`;
    const sessionToken = crypto.randomBytes(32).toString("hex");
    const expiresAt = Date.now() + 30 * 24 * 60 * 60 * 1000; // 30 días

    const session = {
      user: {
        id: userId,
        email: confirmation.email,
        name: confirmation.email.split("@")[0],
        confirmedAt: Date.now(),
        createdAt: Date.now(),
      },
      token: sessionToken,
      expiresAt,
    };

    // TODO: Guardar usuario en Supabase
    // TODO: Guardar sesión en base de datos

    // Limpiar confirmación pendiente
    pendingConfirmations.delete(token);

    console.log(`✓ Email confirmado: ${confirmation.email}`);

    res.json({ session });
  } catch (error) {
    console.error("Error en /api/auth/confirm-email:", error);
    res.status(500).json({ error: "Error confirmando email" });
  }
});

export default router;
