import express from "express";
import { createServer } from "http";
import path from "path";
import { fileURLToPath } from "url";
import authRouter from "./auth.js";
import projectsRouter from "./projects.js";
import conversationsRouter from "./conversations.js";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const server = createServer(app);

  // Middleware
  app.use(express.json());

  // ===== AUTH ROUTES =====
  app.use("/api/auth", authRouter);

  // ===== PROJECTS ROUTES =====
  app.use("/api/projects", projectsRouter);

  // ===== CONVERSATIONS ROUTES =====
  app.use("/api/conversations", conversationsRouter);

  // ===== API ENDPOINTS =====

  /**
   * GET /api/ai-config
   * Retorna configuración de IA sin exponer las claves API
   * Las claves están en variables de entorno del servidor
   */
  app.get("/api/ai-config", (_req, res) => {
    try {
      const config = {
        mistral: {
          model: process.env.MISTRAL_MODEL || "mistral-large",
          temperature: parseFloat(process.env.MISTRAL_TEMPERATURE || "0.7"),
          maxTokens: parseInt(process.env.MISTRAL_MAX_TOKENS || "1024"),
          // NOTA: API_KEY NO se envía al frontend
        },
        supabase: {
          url: process.env.SUPABASE_URL,
          // NOTA: API_KEY NO se envía al frontend
        },
        configured: !!(process.env.MISTRAL_API_KEY && process.env.SUPABASE_API_KEY),
      };

      res.json(config);
    } catch (error) {
      console.error("Error en /api/ai-config:", error);
      res.status(500).json({ error: "Error obteniendo configuración" });
    }
  });

  /**
   * POST /api/ai/message
   * Envía mensaje a Mistral AI desde el backend
   * Las claves API están protegidas en variables de entorno
   */
  app.post("/api/ai/message", async (req, res) => {
    try {
      const { message, model } = req.body;

      if (!message) {
        return res.status(400).json({ error: "Mensaje requerido" });
      }

      if (!process.env.MISTRAL_API_KEY) {
        return res.status(500).json({ error: "Mistral API key no configurada" });
      }

      const mistralModel = model || process.env.MISTRAL_MODEL || "mistral-large";

      const response = await fetch("https://api.mistral.ai/v1/chat/completions", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${process.env.MISTRAL_API_KEY}`,
        },
        body: JSON.stringify({
          model: mistralModel,
          messages: [{ role: "user", content: message }],
          temperature: parseFloat(process.env.MISTRAL_TEMPERATURE || "0.7"),
          max_tokens: parseInt(process.env.MISTRAL_MAX_TOKENS || "1024"),
        }),
      });

      if (!response.ok) {
        const error = await response.json();
        console.error("Mistral API error:", error);
        return res.status(response.status).json({ error: "Error en Mistral API" });
      }

      const data = await response.json();
      const content = data.choices?.[0]?.message?.content;

      res.json({ content });
    } catch (error) {
      console.error("Error en /api/ai/message:", error);
      res.status(500).json({ error: "Error procesando mensaje" });
    }
  });

  // ===== STATIC FILES =====

  // Serve static files from dist/public in production
  const staticPath =
    process.env.NODE_ENV === "production"
      ? path.resolve(__dirname, "public")
      : path.resolve(__dirname, "..", "dist", "public");

  app.use(express.static(staticPath));

  // Handle client-side routing - serve index.html for all routes
  app.get("*", (_req, res) => {
    res.sendFile(path.join(staticPath, "index.html"));
  });

  const port = process.env.PORT || 3000;

  server.listen(port, () => {
    console.log(`Server running on http://localhost:${port}/`);
    console.log(`✓ AI Config: ${process.env.MISTRAL_API_KEY ? "Configurado" : "No configurado"}`);
    console.log(`✓ Auth: Email confirmation enabled`);
    console.log(`✓ Supabase: ${process.env.SUPABASE_URL ? "Conectado" : "No configurado"}`);
    console.log(`✓ Projects API: /api/projects`);
    console.log(`✓ Conversations API: /api/conversations`);
  });
}

startServer().catch(console.error);
