/**
 * Projects API Routes
 * Gestiona CRUD de proyectos multiproyecto
 */

import { Router } from "express";
import { supabase, DbProject, handleSupabaseError } from "./supabase.js";

const router = Router();

/**
 * GET /api/projects
 * Obtener todos los proyectos del usuario autenticado
 */
router.get("/", async (req, res) => {
  try {
    // TODO: Obtener user_id del token JWT
    const userId = req.headers["x-user-id"] as string;

    if (!userId) {
      return res.status(401).json({ error: "Usuario no autenticado" });
    }

    const { data, error } = await supabase
      .from("projects")
      .select("*")
      .eq("user_id", userId)
      .eq("is_archived", false)
      .order("created_at", { ascending: false });

    if (error) {
      throw error;
    }

    res.json({ projects: data });
  } catch (error) {
    console.error("Error en GET /api/projects:", error);
    res.status(500).json({ error: handleSupabaseError(error) });
  }
});

/**
 * GET /api/projects/:id
 * Obtener un proyecto específico
 */
router.get("/:id", async (req, res) => {
  try {
    const userId = req.headers["x-user-id"] as string;
    const { id } = req.params;

    if (!userId) {
      return res.status(401).json({ error: "Usuario no autenticado" });
    }

    const { data, error } = await supabase
      .from("projects")
      .select("*")
      .eq("id", id)
      .eq("user_id", userId)
      .single();

    if (error) {
      if (error.code === "PGRST116") {
        return res.status(404).json({ error: "Proyecto no encontrado" });
      }
      throw error;
    }

    res.json({ project: data });
  } catch (error) {
    console.error("Error en GET /api/projects/:id:", error);
    res.status(500).json({ error: handleSupabaseError(error) });
  }
});

/**
 * POST /api/projects
 * Crear un nuevo proyecto
 */
router.post("/", async (req, res) => {
  try {
    const userId = req.headers["x-user-id"] as string;
    const { name, description, root_path } = req.body;

    if (!userId) {
      return res.status(401).json({ error: "Usuario no autenticado" });
    }

    if (!name) {
      return res.status(400).json({ error: "Nombre del proyecto requerido" });
    }

    const { data, error } = await supabase
      .from("projects")
      .insert({
        user_id: userId,
        name,
        description: description || null,
        root_path: root_path || null,
        is_archived: false,
      })
      .select()
      .single();

    if (error) {
      throw error;
    }

    res.status(201).json({ project: data });
  } catch (error) {
    console.error("Error en POST /api/projects:", error);
    res.status(500).json({ error: handleSupabaseError(error) });
  }
});

/**
 * PUT /api/projects/:id
 * Actualizar un proyecto
 */
router.put("/:id", async (req, res) => {
  try {
    const userId = req.headers["x-user-id"] as string;
    const { id } = req.params;
    const { name, description, root_path } = req.body;

    if (!userId) {
      return res.status(401).json({ error: "Usuario no autenticado" });
    }

    // Verificar que el proyecto pertenece al usuario
    const { data: project, error: fetchError } = await supabase
      .from("projects")
      .select("user_id")
      .eq("id", id)
      .single();

    if (fetchError || project?.user_id !== userId) {
      return res.status(403).json({ error: "No tienes permiso para actualizar este proyecto" });
    }

    const { data, error } = await supabase
      .from("projects")
      .update({
        name: name || undefined,
        description: description !== undefined ? description : undefined,
        root_path: root_path !== undefined ? root_path : undefined,
        updated_at: new Date().toISOString(),
      })
      .eq("id", id)
      .select()
      .single();

    if (error) {
      throw error;
    }

    res.json({ project: data });
  } catch (error) {
    console.error("Error en PUT /api/projects/:id:", error);
    res.status(500).json({ error: handleSupabaseError(error) });
  }
});

/**
 * DELETE /api/projects/:id
 * Archivar un proyecto (soft delete)
 */
router.delete("/:id", async (req, res) => {
  try {
    const userId = req.headers["x-user-id"] as string;
    const { id } = req.params;

    if (!userId) {
      return res.status(401).json({ error: "Usuario no autenticado" });
    }

    // Verificar que el proyecto pertenece al usuario
    const { data: project, error: fetchError } = await supabase
      .from("projects")
      .select("user_id")
      .eq("id", id)
      .single();

    if (fetchError || project?.user_id !== userId) {
      return res.status(403).json({ error: "No tienes permiso para eliminar este proyecto" });
    }

    const { error } = await supabase
      .from("projects")
      .update({ is_archived: true })
      .eq("id", id);

    if (error) {
      throw error;
    }

    res.json({ message: "Proyecto archivado" });
  } catch (error) {
    console.error("Error en DELETE /api/projects/:id:", error);
    res.status(500).json({ error: handleSupabaseError(error) });
  }
});

export default router;
