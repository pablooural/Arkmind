# Supabase Schema - UX Arquitecto

**Fecha**: 27 de Mayo de 2026  
**Versión**: Arkitectgr v2.3 - Database Schema  
**Estado**: ✓ Documentado

---

## Tablas Necesarias

### 1. users

Almacena información de usuarios autenticados.

```sql
CREATE TABLE users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email VARCHAR(255) NOT NULL UNIQUE,
  name VARCHAR(255),
  created_at TIMESTAMP DEFAULT NOW(),
  confirmed_at TIMESTAMP,
  last_login TIMESTAMP,
  is_active BOOLEAN DEFAULT true
);

CREATE INDEX idx_users_email ON users(email);
```

**Campos**:
- `id` - UUID único del usuario
- `email` - Email único (clave de login)
- `name` - Nombre del usuario
- `created_at` - Fecha de creación
- `confirmed_at` - Fecha de confirmación de email
- `last_login` - Último acceso
- `is_active` - Usuario activo o desactivado

---

### 2. projects

Almacena proyectos del usuario.

```sql
CREATE TABLE projects (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  name VARCHAR(255) NOT NULL,
  description TEXT,
  root_path VARCHAR(1024),
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW(),
  is_archived BOOLEAN DEFAULT false
);

CREATE INDEX idx_projects_user_id ON projects(user_id);
CREATE INDEX idx_projects_created_at ON projects(created_at);
```

**Campos**:
- `id` - UUID único del proyecto
- `user_id` - Referencia a usuario
- `name` - Nombre del proyecto
- `description` - Descripción
- `root_path` - Ruta raíz del proyecto
- `created_at` - Fecha de creación
- `updated_at` - Última actualización
- `is_archived` - Proyecto archivado

---

### 3. conversations

Almacena conversaciones por nodo (.ai.md).

```sql
CREATE TABLE conversations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id UUID NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  node_path VARCHAR(1024) NOT NULL,
  goal VARCHAR(50),
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_conversations_project_id ON conversations(project_id);
CREATE INDEX idx_conversations_node_path ON conversations(node_path);
CREATE UNIQUE INDEX idx_conversations_unique ON conversations(project_id, node_path);
```

**Campos**:
- `id` - UUID único de conversación
- `project_id` - Referencia a proyecto
- `node_path` - Ruta del nodo (archivo/carpeta)
- `goal` - Objetivo cognitivo (architecture, refactor, debug, etc.)
- `created_at` - Fecha de creación
- `updated_at` - Última actualización

---

### 4. messages

Almacena mensajes de conversaciones.

```sql
CREATE TABLE messages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  conversation_id UUID NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
  role VARCHAR(20) NOT NULL,
  content TEXT NOT NULL,
  message_type VARCHAR(50),
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_messages_conversation_id ON messages(conversation_id);
CREATE INDEX idx_messages_created_at ON messages(created_at);
```

**Campos**:
- `id` - UUID único del mensaje
- `conversation_id` - Referencia a conversación
- `role` - "user" o "assistant"
- `content` - Contenido del mensaje
- `message_type` - "text", "code", "diff", "warning", "proposal", "snapshot", "action"
- `created_at` - Fecha de creación

---

### 5. snapshots

Almacena snapshots automáticos del workspace.

```sql
CREATE TABLE snapshots (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id UUID NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  workspace_state JSONB NOT NULL,
  total_size BIGINT,
  created_at TIMESTAMP DEFAULT NOW(),
  description TEXT
);

CREATE INDEX idx_snapshots_project_id ON snapshots(project_id);
CREATE INDEX idx_snapshots_created_at ON snapshots(created_at);
```

**Campos**:
- `id` - UUID único del snapshot
- `project_id` - Referencia a proyecto
- `workspace_state` - Estado completo del workspace (JSON)
- `total_size` - Tamaño en bytes
- `created_at` - Fecha de creación
- `description` - Descripción del snapshot

---

### 6. sessions

Almacena sesiones de usuario (tokens).

```sql
CREATE TABLE sessions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  token VARCHAR(255) NOT NULL UNIQUE,
  expires_at TIMESTAMP NOT NULL,
  created_at TIMESTAMP DEFAULT NOW(),
  last_used TIMESTAMP
);

CREATE INDEX idx_sessions_user_id ON sessions(user_id);
CREATE INDEX idx_sessions_token ON sessions(token);
CREATE INDEX idx_sessions_expires_at ON sessions(expires_at);
```

**Campos**:
- `id` - UUID único de sesión
- `user_id` - Referencia a usuario
- `token` - Token de sesión
- `expires_at` - Expiración del token
- `created_at` - Fecha de creación
- `last_used` - Último uso

---

## Relaciones

```
users (1) ──────→ (N) projects
  ↓
  └──→ (N) sessions

projects (1) ──────→ (N) conversations
  ↓
  └──→ (N) snapshots

conversations (1) ──────→ (N) messages
```

---

## Políticas de Seguridad (RLS)

### users
```sql
-- Usuarios solo pueden ver su propio perfil
ALTER TABLE users ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own profile"
  ON users FOR SELECT
  USING (auth.uid() = id);

CREATE POLICY "Users can update own profile"
  ON users FOR UPDATE
  USING (auth.uid() = id);
```

### projects
```sql
-- Usuarios solo pueden ver/editar sus propios proyectos
ALTER TABLE projects ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own projects"
  ON projects FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create projects"
  ON projects FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own projects"
  ON projects FOR UPDATE
  USING (auth.uid() = user_id);

CREATE POLICY "Users can delete own projects"
  ON projects FOR DELETE
  USING (auth.uid() = user_id);
```

### conversations
```sql
-- Usuarios solo pueden ver conversaciones de sus proyectos
ALTER TABLE conversations ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view conversations in own projects"
  ON conversations FOR SELECT
  USING (
    project_id IN (
      SELECT id FROM projects WHERE user_id = auth.uid()
    )
  );
```

---

## Cómo Crear las Tablas

### Opción 1: SQL Editor en Supabase

1. Abre https://app.supabase.com
2. Ve a SQL Editor
3. Copia y pega cada CREATE TABLE
4. Ejecuta

### Opción 2: Migrations (Recomendado)

```bash
# Crear migration
supabase migration new create_initial_schema

# Editar archivo en supabase/migrations/
# Agregar todos los CREATE TABLE

# Aplicar
supabase db push
```

---

## Integración en Backend

### Conectar a Supabase

```typescript
import { createClient } from "@supabase/supabase-js";

const supabaseUrl = process.env.SUPABASE_URL;
const supabaseKey = process.env.SUPABASE_API_KEY;

const supabase = createClient(supabaseUrl, supabaseKey);
```

### Guardar Usuario en Confirmación

```typescript
// En server/auth.ts
const { data, error } = await supabase
  .from("users")
  .insert({
    email: confirmation.email,
    name: confirmation.email.split("@")[0],
    confirmed_at: new Date(),
  })
  .select()
  .single();

if (error) throw error;
const userId = data.id;
```

### Guardar Sesión

```typescript
const { data, error } = await supabase
  .from("sessions")
  .insert({
    user_id: userId,
    token: sessionToken,
    expires_at: new Date(expiresAt),
  });
```

### Crear Proyecto

```typescript
const { data, error } = await supabase
  .from("projects")
  .insert({
    user_id: userId,
    name: "Mi Proyecto",
    root_path: "/home/user/projects",
  })
  .select()
  .single();
```

---

## Próximos Pasos

1. **Crear tablas en Supabase** - Usar SQL Editor o migrations
2. **Configurar RLS** - Políticas de seguridad
3. **Actualizar server/auth.ts** - Guardar usuarios en BD
4. **Crear endpoints de proyectos** - CRUD de proyectos
5. **Crear endpoints de conversaciones** - CRUD de conversaciones

---

**Fin del Schema de Supabase**
