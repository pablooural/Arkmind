# UX Arquitecto - Arquitectura Desacoplada

## Descripción General

Este proyecto es una refactorización desacoplada del componente monolítico UXArquitecto. La arquitectura está organizada en módulos independientes que se conectan a través de interfaces claras, facilitando el mantenimiento, testing y extensión del código.

## Estructura de Carpetas

```
client/src/
├── types/
│   └── theme.ts              # Definiciones de tipos (Theme, HSV, etc.)
├── utils/
│   ├── colorSystem.ts        # Sistema de 5 colores predefinidos
│   └── colorConversion.ts    # Conversión entre formatos de color
├── components/
│   ├── ColorWheel.tsx        # Rueda de colores HSV interactiva
│   ├── ConfigMenu.tsx        # Menú de configuración
│   ├── ChatPanel.tsx         # Panel de chat (Panel A)
│   ├── FileExplorer.tsx      # Explorador de archivos (Panel B)
│   ├── ResizableDivider.tsx  # Divisor redimensionable
│   ├── SplitView.tsx         # Vista de división
│   └── SlideModeView.tsx     # Vista de modo lateral
├── pages/
│   └── DualPanelLayout.tsx   # Componente principal
└── App.tsx                    # Punto de entrada
```

## Módulos Principales

### 1. **types/theme.ts**
Define la estructura de datos del sistema de temas.

**Interfaces:**
- `ThemeColors` - Colores individuales (bg, surface, accent, text, sub)
- `Theme` - Tema completo con nombre
- `HSV` - Modelo de color HSV
- `ColorPickerState` - Estado del selector de colores
- `LayoutMode` - Modos de layout disponibles

### 2. **utils/colorSystem.ts**
Sistema de 5 paletas predefinidas con colores para fondo y panel.

**Constantes:**
- `COLOR_PRESETS` - Array de 5 temas predefinidos
  1. Noche Azul
  2. Bosque
  3. Rojo Carbón
  4. Púrpura
  5. Océano

**Funciones:**
- `getDefaultTheme()` - Retorna el tema por defecto
- `findThemeByName(name)` - Busca un tema por nombre

### 3. **utils/colorConversion.ts**
Utilidades para conversión entre formatos de color.

**Funciones:**
- `hexToHsv(hex)` - Convierte Hex a HSV
- `hsvToHex(hsv)` - Convierte HSV a Hex

### 4. **components/ColorWheel.tsx**
Rueda de colores HSV interactiva.

**Props:**
- `color: string` - Color actual en formato Hex
- `onChange: (color: string) => void` - Callback al cambiar color

**TODO:**
- Implementar dibujo de rueda en canvas
- Manejar interacciones mouse/touch
- Slider de brillo

### 5. **components/ConfigMenu.tsx**
Menú de configuración con selector de paletas y colores personalizados.

**Props:**
- `open: boolean` - Estado del menú
- `onClose: () => void` - Callback al cerrar
- `theme: Theme` - Tema actual
- `onThemeChange: (theme: Theme) => void` - Callback al cambiar tema

**Características:**
- Selector de paletas predefinidas
- Selector de colores individuales (fondo, panel, acento, texto)
- Modal con ColorWheel para personalización

### 6. **components/ChatPanel.tsx**
Panel de chat con IA (Panel A).

**Props:**
- `theme: Theme` - Tema actual

**TODO:**
- Implementar lógica de envío de mensajes
- Conectar con API de IA
- Manejar estados de carga

### 7. **components/FileExplorer.tsx**
Explorador de archivos con navegación jerárquica (Panel B).

**Props:**
- `theme: Theme` - Tema actual

**TODO:**
- Implementar estructura de carpetas y archivos
- Navegación con breadcrumb
- Selección y visualización de archivos

### 8. **components/ResizableDivider.tsx**
Divisor redimensionable para vistas de división.

**Props:**
- `direction: "vertical" | "horizontal"` - Dirección del divisor
- `onRatioChange: (ratio: number) => void` - Callback al redimensionar
- `accent: string` - Color de acento

**Características:**
- Drag interactivo
- Soporte touch
- Límites de redimensionamiento (15% - 85%)

### 9. **components/SplitView.tsx**
Vista de división con dos paneles redimensionables.

**Props:**
- `direction: "vertical" | "horizontal"` - Dirección de división
- `panelA: React.ReactNode` - Contenido del panel A
- `panelB: React.ReactNode` - Contenido del panel B
- `accent: string` - Color de acento
- `theme: Theme` - Tema actual

### 10. **components/SlideModeView.tsx**
Vista de modo lateral con panel deslizable.

**Props:**
- `sideOpen: boolean` - Estado del panel lateral
- `setSideOpen: (open: boolean) => void` - Callback para abrir/cerrar
- `sideContent: React.ReactNode` - Contenido del panel lateral
- `fixedContent: React.ReactNode` - Contenido del panel principal
- `flipping: boolean` - Estado de animación de volteo
- `theme: Theme` - Tema actual

**Características:**
- Panel lateral deslizable
- Borde arrastrable para redimensionar
- Pestaña de control (‹ / ›)
- Animación de volteo

### 11. **pages/DualPanelLayout.tsx**
Componente principal que orquesta todos los módulos.

**Modos de vista:**
- `slide` - Panel lateral deslizable
- `split-v` - División vertical
- `split-h` - División horizontal

**Estado:**
- Layout mode
- Panel lateral abierto/cerrado
- Paneles intercambiados
- Animación de volteo
- Menú de configuración abierto/cerrado
- Tema actual

**Funcionalidades:**
- Cambio de modo de vista
- Intercambio de paneles
- Selector de tema
- Barra de estado

## Flujo de Datos

```
DualPanelLayout (Estado Global)
├── theme: Theme
├── mode: "slide" | "split-v" | "split-h"
├── sideOpen: boolean
├── swapped: boolean
└── configOpen: boolean
    │
    ├─→ ConfigMenu
    │   └─→ ColorWheel
    │
    ├─→ SlideModeView / SplitView
    │   ├─→ ChatPanel
    │   └─→ FileExplorer
    │
    └─→ ResizableDivider
```

## Paletas de Color Predefinidas

### 5 Colores Seleccionables

Cada paleta incluye:
- **bg** - Color de fondo principal
- **surface** - Color de panel/superficie
- **accent** - Color de acento (botones, highlights)
- **text** - Color de texto principal
- **sub** - Color de texto secundario

### Paletas Disponibles

1. **Noche Azul** - Tema oscuro con acento amarillo
2. **Bosque** - Tema oscuro con acento verde
3. **Rojo Carbón** - Tema oscuro con acento rojo
4. **Púrpura** - Tema oscuro con acento púrpura
5. **Océano** - Tema oscuro con acento azul claro

## Puntos de Conexión (TODOs)

### ColorWheel
- [ ] Dibujar rueda HSV en canvas
- [ ] Manejar eventos mouse/touch
- [ ] Implementar slider de brillo
- [ ] Actualizar color en tiempo real

### ChatPanel
- [ ] Implementar lógica de envío de mensajes
- [ ] Conectar con API de IA
- [ ] Manejar estados de carga
- [ ] Scroll automático al nuevo mensaje

### FileExplorer
- [ ] Crear estructura de datos de archivos
- [ ] Implementar navegación
- [ ] Mostrar información de archivos
- [ ] Manejar selección

### ConfigMenu
- [ ] Implementar secciones de Perfil, Cuenta, Notificaciones
- [ ] Conectar ColorWheel con selector de colores

## Cómo Usar

### 1. Iniciar el Proyecto
```bash
pnpm install
pnpm dev
```

### 2. Implementar un Módulo
Cada componente tiene comentarios `// TODO` indicando qué implementar:

```tsx
// En ChatPanel.tsx
const send = async () => {
  // TODO: Implementar lógica de envío de mensajes
};
```

### 3. Conectar Módulos
Los módulos se conectan a través de props y callbacks:

```tsx
// En DualPanelLayout.tsx
<ConfigMenu
  open={configOpen}
  onClose={() => setConfigOpen(false)}
  theme={theme}
  onThemeChange={setTheme}
/>
```

## Características del Sistema

### Modos de Vista
- **Lateral (slide)** - Panel lateral deslizable con pestaña de control
- **División Vertical (split-v)** - Dos paneles lado a lado
- **División Horizontal (split-h)** - Dos paneles uno encima del otro

### Interactividad
- Intercambio de paneles con animación de volteo
- Redimensionamiento de paneles con drag
- Selector de tema con paletas predefinidas
- Personalización de colores individuales

### Responsive
- Soporte completo para touch
- Límites de redimensionamiento
- Animaciones suaves

## Próximos Pasos

1. Implementar lógica de ColorWheel
2. Conectar ChatPanel con API de IA
3. Crear estructura de datos para FileExplorer
4. Implementar persistencia de tema
5. Agregar más paletas de color
6. Optimizar rendimiento

## Notas de Desarrollo

- Todos los colores usan formato Hex (#RRGGBB)
- El sistema de temas es completamente desacoplado
- Los componentes son reutilizables y testables
- Las animaciones usan CSS transitions para mejor rendimiento
- El código sigue convenciones de React 19+
