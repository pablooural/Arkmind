# Claves API Seguras en Backend - Log Completo

**Fecha**: 27 de Mayo de 2026  
**Versión**: Arkitectgr v2.1 - Secure Backend  
**Estado**: ✓ Completado

---

## Resumen

Se movieron todas las claves API del frontend al backend. Las claves están protegidas en variables de entorno del servidor. El frontend solo recibe configuración sin exponer las claves. Arquitectura de seguridad de 3 capas.

---

## Arquitectura de Seguridad

```
┌─────────────────────────────────────────────────────────────┐
│ CAPA 1: FRONTEND (React)                                    │
│ ✗ NO tiene acceso a claves API                              │
│ ✓ Obtiene configuración desde /api/ai-config                │
│ ✓ Envía mensajes a /api/ai/message                          │
└─────────────────────────────────────────────────────────────┘
                           ↓ HTTPS
┌─────────────────────────────────────────────────────────────┐
│ CAPA 2: BACKEND (Express + Node.js)                         │
│ ✓ Tiene acceso a claves API en variables de entorno         │
│ ✓ Valida solicitudes del frontend                           │
│ ✓ Maneja autenticación con Mistral AI                       │
│ ✓ Maneja autenticación con Supabase                         │
└─────────────────────────────────────────────────────────────┘
                           ↓ HTTPS
┌─────────────────────────────────────────────────────────────┐
│ CAPA 3: APIS EXTERNAS                                       │
│ ✓ Mistral AI API (https://api.mistral.ai)                   │
│ ✓ Supabase API (https://mkrliicvotzlmsycyuak.supabase.co)   │
└─────────────────────────────────────────────────────────────┘
```

---

## Variables de Entorno (Backend)

Las siguientes variables están en el servidor y **NO se exponen al frontend**:

```bash
# Supabase
SUPABASE_URL=https://mkrliicvotzlmsycyuak.supabase.co
SUPABASE_API_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...

# Mistral AI
MISTRAL_API_KEY=ndxsa1r3XoXSnmZOZ9Rx3K5adn9oBaZR
MISTRAL_MODEL=mistral-large
MISTRAL_TEMPERATURE=0.7
MISTRAL_MAX_TOKENS=1024
```

---

## Endpoints Backend

### 1. GET /api/ai-config

**Responsabilidad**: Obtener configuración de IA sin exponer claves

**Respuesta**:
```json
{
  "mistral": {
    "model": "mistral-large",
    "temperature": 0.7,
    "maxTokens": 1024
  },
  "supabase": {
    "url": "https://mkrliicvotzlmsycyuak.supabase.co"
  },
  "configured": true
}
```

**Seguridad**:
- ✓ NO devuelve `MISTRAL_API_KEY`
- ✓ NO devuelve `SUPABASE_API_KEY`
- ✓ Solo información de configuración pública

### 2. POST /api/ai/message

**Responsabilidad**: Procesar mensajes de usuario y enviar a Mistral AI

**Request**:
```json
{
  "message": "Hola, ¿cómo estás?",
  "model": "mistral-large"
}
```

**Response**:
```json
{
  "content": "¡Hola! Estoy bien, gracias por preguntar..."
}
```

**Flujo Seguro**:
1. Frontend envía mensaje sin claves
2. Backend recibe mensaje
3. Backend valida que MISTRAL_API_KEY exista
4. Backend autentica con Mistral usando MISTRAL_API_KEY
5. Backend recibe respuesta de Mistral
6. Backend devuelve respuesta al frontend
7. Claves nunca salen del servidor

**Manejo de Errores**:
- Si `MISTRAL_API_KEY` no existe: 500 "Mistral API key no configurada"
- Si Mistral API falla: 500 "Error en Mistral API"
- Si request es inválido: 400 "Mensaje requerido"

---

## Cliente Frontend (aiApi.ts)

### getAIConfig()

```typescript
export async function getAIConfig(): Promise<AIConfigResponse> {
  const response = await fetch("/api/ai-config");
  return await response.json();
}
```

**Uso**:
```typescript
const config = await getAIConfig();
console.log(config.mistral.model); // "mistral-large"
console.log(config.configured); // true
```

### sendMessageToAI()

```typescript
export async function sendMessageToAI(message: string, model?: string): Promise<string> {
  const response = await fetch("/api/ai/message", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ message, model }),
  });
  const data = await response.json();
  return data.content;
}
```

**Uso**:
```typescript
const response = await sendMessageToAI("¿Qué es React?", "mistral-large");
console.log(response); // "React es una librería de JavaScript..."
```

---

## Hook useAI (Actualizado)

### Cambios Principales

**Antes** (Claves en frontend):
```typescript
// ❌ INSEGURO: Claves en frontend
const aiManager = new AIManager({
  apiKey: "ndxsa1r3XoXSnmZOZ9Rx3K5adn9oBaZR", // ¡Expuesto!
});
```

**Después** (Claves en backend):
```typescript
// ✓ SEGURO: Claves en servidor
useEffect(() => {
  const loadConfig = async () => {
    const config = await getAIConfig(); // Obtiene del backend
    setIsConfigured(config.configured);
    setCurrentModel(config.mistral.model);
  };
  loadConfig();
}, []);
```

### Flujo de sendMessage

```typescript
const handleSendMessage = async (sessionId: string, userMessage: string) => {
  // 1. Validar que IA esté configurada (en servidor)
  if (!isConfigured) {
    setError("IA no está configurada en el servidor.");
    return null;
  }

  // 2. Agregar mensaje a sesión local
  sessionManager.addMessage(sessionId, userMessage);

  // 3. Enviar a backend (sin claves)
  const aiResponse = await sendMessageToAI(userMessage, currentModel);

  // 4. Agregar respuesta a sesión
  sessionManager.addMessage(sessionId, aiResponse);

  return aiResponse;
};
```

---

## Flujo Completo de Seguridad

```
Usuario escribe en ChatPanel
  ↓
ChatPanel.handleSend()
  ├─ Valida que haya texto
  ├─ Llama useAI.sendMessage(sessionId, userMessage)
  │   ├─ Valida isConfigured (del backend)
  │   ├─ Agrega mensaje a SessionManager
  │   ├─ Llama aiApi.sendMessageToAI(userMessage)
  │   │   ├─ Fetch POST /api/ai/message
  │   │   │   ├─ Backend recibe { message, model }
  │   │   │   ├─ Backend obtiene MISTRAL_API_KEY de env
  │   │   │   ├─ Backend autentica con Mistral
  │   │   │   ├─ Mistral procesa y responde
  │   │   │   ├─ Backend devuelve { content }
  │   │   │   └─ ✓ Claves NUNCA salen del servidor
  │   │   └─ Retorna content
  │   ├─ Agrega respuesta a SessionManager
  │   └─ Retorna respuesta
  ├─ Limpiar input
  └─ Renderizar nuevo mensaje
```

---

## Comparación: Antes vs Después

| Aspecto | Antes (Inseguro) | Después (Seguro) |
|--------|------------------|-----------------|
| Ubicación de claves | Frontend (expuesto) | Backend (protegido) |
| Visibilidad en DevTools | ✗ Visible en Network | ✓ No visible |
| Visibilidad en código fuente | ✗ En variables JS | ✓ No existe |
| Riesgo de exposición | Alto (XSS, inspección) | Bajo (aislado en servidor) |
| Validación de claves | Frontend (débil) | Backend (fuerte) |
| Manejo de errores | Frontend (limitado) | Backend (completo) |
| Escalabilidad | Baja (1 clave por usuario) | Alta (1 clave en servidor) |

---

## Seguridad Adicional

### 1. HTTPS Obligatorio

En producción, asegurar que:
- ✓ Todas las comunicaciones usen HTTPS
- ✓ No hay HTTP sin encripción
- ✓ Certificados SSL válidos

### 2. Rate Limiting

Agregar en el futuro:
```typescript
// Limitar solicitudes a /api/ai/message
app.use("/api/ai/message", rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutos
  max: 100, // 100 solicitudes por ventana
}));
```

### 3. Validación de Input

Ya implementado:
```typescript
if (!message) {
  return res.status(400).json({ error: "Mensaje requerido" });
}
```

### 4. Logging de Errores

Ya implementado:
```typescript
console.error("Mistral API error:", error);
```

---

## Próximos Pasos

### Corto Plazo
1. **Agregar autenticación de usuario** - JWT tokens
2. **Implementar rate limiting** - Prevenir abuso
3. **Agregar logging de auditoría** - Rastrear uso

### Mediano Plazo
1. **Encripción de datos en Supabase** - Datos en reposo
2. **Rotación de claves API** - Cambiar periódicamente
3. **Monitoreo de uso** - Alertas de anomalías

### Largo Plazo
1. **OAuth2 con Mistral** - Mejor autenticación
2. **Proxy inverso** - Capas adicionales de seguridad
3. **WAF (Web Application Firewall)** - Protección contra ataques

---

## Validación

✓ Claves API movidas al backend  
✓ Endpoints /api/ai-config y /api/ai/message implementados  
✓ Frontend obtiene configuración sin exponer claves  
✓ aiApi.ts con funciones seguras  
✓ useAI hook actualizado  
✓ SecretsDialog removido del frontend  
✓ ConfigMenu muestra "✓ Configurado en servidor"  
✓ TypeScript compila sin errores  
✓ Flujo de seguridad validado  

---

**Fin del Log de Claves API Seguras**
