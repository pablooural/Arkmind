# UXArquitecto - Workspace Engine Desacoplado

## Visión General

El **Workspace Engine** es el núcleo desacoplado de UXArquitecto. Separa completamente la lógica operativa de la interfaz visual, permitiendo que la UI cambie sin afectar el motor.

### Principios Arquitectónicos

**Desacoplamiento Total**: La UI consume estados y acciones desde el motor, nunca accede directamente a filesystem, IA o estado global.

**Seguridad por Defecto**: Toda operación destructiva genera snapshots automáticos, se valida en sandbox y es reversible.

**Transaccionalidad**: Las operaciones son atómicas y pueden fallar de forma segura.

**Resiliencia**: El sistema asume que todo puede fallar y proporciona recuperación inmediata.

---

## Estructura del Núcleo

```
/core
  ├── types.ts              # Definiciones de tipos
  ├── snapshots.ts          # Sistema de snapshots y rollback
  ├── transactions.ts       # Gestor de transacciones
  ├── workspace.ts          # Gestor de workspace y contextos
  ├── filesystem.ts         # Abstracción de filesystem
  └── index.ts              # Punto de entrada único
```

---

## Módulos Principales

### 1. **SnapshotManager** (`snapshots.ts`)

Gestiona snapshots automáticos y rollback.

#### Responsabilidades

- Crear snapshots antes de operaciones destructivas
- Almacenar metadatos de snapshots
- Implementar rollback
- Gestionar almacenamiento

#### API Pública

```typescript
createSnapshot(contextPath, files, reason, label?)
  → Promise<Snapshot>

getSnapshot(snapshotId)
  → SnapshotMetadata | undefined

listSnapshots(contextPath)
  → SnapshotMetadata[]

rollback(snapshotId)
  → Promise<boolean>

deleteSnapshot(snapshotId)
  → boolean

cleanOldSnapshots(daysOld)
  → Promise<number>
```

#### Flujo de Snapshot

1. Detectar acción destructiva
2. Crear snapshot automático
3. Guardar estado anterior
4. Permitir operación
5. Si falla: rollback automático

---

### 2. **TransactionManager** (`transactions.ts`)

Gestiona transacciones seguras con validación y sandbox.

#### Responsabilidades

- Validar operaciones antes de ejecutar
- Ejecutar en sandbox
- Crear snapshots automáticos
- Gestionar permisos temporales
- Rollback en caso de error

#### API Pública

```typescript
createTransaction(type, targetPath, operation)
  → Promise<Transaction>

validateTransaction(transactionId)
  → Promise<boolean>

simulateTransaction(transactionId)
  → Promise<SimulationResult>

executeTransaction(transactionId)
  → Promise<boolean>

confirmTransaction(transactionId)
  → boolean

rollbackTransaction(transactionId)
  → Promise<boolean>

grantPermission(type, resourcePath, expiresIn?)
  → Permission

hasPermission(type, resourcePath)
  → boolean

revokePermission(permissionId)
  → boolean
```

#### Flujo de Transacción

1. Crear transacción
2. Crear snapshot automático
3. Validar operación
4. Simular en sandbox
5. Ejecutar si simulación exitosa
6. Confirmar operación
7. Si falla en cualquier paso: rollback automático

---

### 3. **WorkspaceManager** (`workspace.ts`)

Gestiona el workspace y contextos.

#### Responsabilidades

- Mantener estado del workspace
- Cambiar contexto raíz (long-press)
- Gestionar paneles
- Coordinar con otros managers

#### API Pública

```typescript
initializeWorkspace(id, name, rootPath)
  → Workspace

getWorkspace()
  → Workspace | null

setActiveContext(contextPath)
  → boolean

getActiveContext()
  → WorkspaceContext | null

getContext(path)
  → WorkspaceContext | null

registerContext(path, context)
  → void

updateContext(path, updates)
  → boolean

onContextChange(listener)
  → () => void  // Unsubscribe function

addPanel(panel)
  → void

removePanel(panelId)
  → boolean

getPanel(panelId)
  → Panel | undefined

updatePanel(panelId, updates)
  → boolean

getPanelsByType(type)
  → Panel[]

getPanelsByContext(contextPath)
  → Panel[]

addFavorite(contextPath, filePath)
  → boolean

removeFavorite(contextPath, filePath)
  → boolean

addRecent(contextPath, filePath)
  → void

getRecentFiles(contextPath, limit)
  → string[]
```

#### Cambio de Contexto Raíz

Cuando el usuario hace long-press en una carpeta del explorer:

1. `setActiveContext(folderPath)` se invoca
2. El workspace actualiza su `activeContextPath`
3. Se notifica a todos los listeners
4. La UI se reenfoca automáticamente
5. El chat se contextualiza
6. Los archivos recientes se filtran
7. Los paneles se actualizan

**Importante**: Esto NO recarga la aplicación, es una actualización contextual desacoplada.

---

### 4. **FilesystemManager** (`filesystem.ts`)

Abstracción desacoplada para operaciones de archivo.

#### Responsabilidades

- Abstraer acceso a filesystem
- Validar operaciones
- Coordinar con transaction manager
- Soportar formatos específicos

#### Formatos Soportados (MVP)

- **Texto**: `.txt`, `.md`
- **Código**: `.ts`, `.tsx`, `.js`, `.jsx`, `.json`
- **Datos**: `.json`, `.yaml`, `.yml`

#### API Pública

```typescript
readFile(path)
  → Promise<FileSystemResult>

writeFile(path, content)
  → Promise<FileSystemResult>

createFolder(path)
  → Promise<FileSystemResult>

deleteFile(path)
  → Promise<FileSystemResult>

moveFile(sourcePath, targetPath)
  → Promise<FileSystemResult>

listDirectory(path)
  → Promise<FileNode[]>

getDirectoryTree(path, maxDepth)
  → Promise<FileNode | null>
```

#### Flujo de Escritura

1. Validar formato
2. Crear transacción
3. Simular en sandbox
4. Ejecutar si simulación exitosa
5. Confirmar
6. Retornar resultado

---

## Tipos Principales

### Workspace

```typescript
interface Workspace {
  id: string;
  name: string;
  rootPath: string;
  activeContextPath: string;  // Contexto raíz actual
  panels: Panel[];
  createdAt: number;
  updatedAt: number;
}
```

### WorkspaceContext

```typescript
interface WorkspaceContext {
  path: string;
  name: string;
  files: FileNode[];
  metadata: {
    favorites: string[];
    recentFiles: string[];
    checkpoints: Snapshot[];
    conversations: ConversationRef[];
  };
}
```

### Panel

```typescript
interface Panel {
  id: string;
  type: "editor" | "chat" | "explorer" | "preview";
  contextPath?: string;
  state?: Record<string, any>;
  position?: "left" | "center" | "right";
  width?: number;
  canMove: boolean;
  canClose: boolean;
  canFocus: boolean;
}
```

### Snapshot

```typescript
interface Snapshot {
  id: string;
  timestamp: number;
  label?: string;
  description?: string;
  contextPath: string;
  metadata: {
    filesCount: number;
    totalSize: number;
    changedFiles: string[];
  };
  storePath: string;
}
```

### Transaction

```typescript
interface Transaction {
  id: string;
  type: "write" | "delete" | "move" | "create" | "refactor";
  targetPath: string;
  snapshotId: string;
  status: "pending" | "validated" | "executed" | "confirmed" | "rolled_back";
  permissions: Permission[];
  simulationResult?: SimulationResult;
  createdAt: number;
  executedAt?: number;
}
```

---

## Patrones de Uso

### Patrón 1: Cambiar Contexto Raíz

```typescript
import { workspaceManager } from "@/core";

// Usuario hace long-press en carpeta
const success = workspaceManager.setActiveContext("/src/components");

// Listeners se notifican automáticamente
workspaceManager.onContextChange((path) => {
  console.log("Contexto cambió a:", path);
  // Actualizar UI
});
```

### Patrón 2: Escribir Archivo (Seguro)

```typescript
import { filesystemManager } from "@/core";

const result = await filesystemManager.writeFile(
  "/src/App.tsx",
  "export default function App() { ... }"
);

if (result.success) {
  console.log("Archivo escrito:", result.path);
} else {
  console.error("Error:", result.error);
  // Rollback automático ya ocurrió
}
```

### Patrón 3: Listar Snapshots

```typescript
import { snapshotManager } from "@/core";

const snapshots = snapshotManager.listSnapshots("/src");
snapshots.forEach((snap) => {
  console.log(`${snap.label} - ${new Date(snap.timestamp).toISOString()}`);
});
```

### Patrón 4: Agregar Favorito

```typescript
import { workspaceManager } from "@/core";

workspaceManager.addFavorite("/src", "/src/components/Button.tsx");
```

---

## Reglas de Seguridad

### Regla 1: Snapshots Automáticos

**TODO proceso potencialmente destructivo DEBE generar snapshot automático antes de ejecutarse.**

Esto incluye:

- Escritura de archivos
- Reemplazo de contenido
- Eliminación
- Refactorización
- Generación automática
- Ejecución de código
- Transformaciones masivas
- Acciones IA
- Operaciones encadenadas
- Cambios estructurales

La creación del snapshot NO es opcional. Debe ser automática y obligatoria.

### Regla 2: Validación en Sandbox

**Toda ejecución debe ocurrir primero en entorno aislado.**

La sandbox debe:

- Impedir corrupción del workspace
- Evitar acceso accidental al sistema
- Contener fallos
- Limitar efectos colaterales
- Validar operaciones antes de aplicar cambios reales

### Regla 3: Permisos Temporales

**NO mantener permisos abiertos permanentemente.**

Permisos deben ser:

- Temporales
- Explícitos
- Ligados a acciones concretas

### Regla 4: Rollback Automático

**Si cualquier validación falla: rollback automático, restauración inmediata, cancelación segura.**

---

## Integración con UI

### Conexión Recomendada

```typescript
// En componente React
import { workspaceManager, coreEngine } from "@/core";
import { useEffect, useState } from "react";

export function ExplorerPanel() {
  const [context, setContext] = useState(workspaceManager.getActiveContext());

  useEffect(() => {
    // Suscribirse a cambios de contexto
    const unsubscribe = workspaceManager.onContextChange(() => {
      setContext(workspaceManager.getActiveContext());
    });

    return unsubscribe;
  }, []);

  const handleLongPress = (folderPath: string) => {
    // Long-press en carpeta
    workspaceManager.setActiveContext(folderPath);
  };

  const handleDeleteFile = async (filePath: string) => {
    // Eliminar archivo (con snapshot automático)
    const result = await coreEngine.filesystem.deleteFile(filePath);
    if (!result.success) {
      console.error("Error:", result.error);
    }
  };

  return (
    // Renderizar explorer con contexto actual
  );
}
```

---

## Próximas Fases

### Fase 2: Conversaciones por Nodo

Implementar `.ai.md` local en cada carpeta para contextos locales.

### Fase 3: Editor con Modos

Implementar editor con modos: lectura, edición, propuesta, revisión.

### Fase 4: Persistencia Real

Conectar con backend para persistencia real de snapshots y transacciones.

### Fase 5: Integración IA

Conectar con APIs de IA respetando contextos locales y globales.

---

## Filosofía Operativa

El sistema asume que:

- La IA puede equivocarse
- El usuario puede equivocarse
- Una operación puede fallar
- Un archivo puede corromperse
- Un contexto puede romperse

Por lo tanto, la seguridad NO depende de "hacer todo bien".

Depende de:

- Snapshots
- Rollback
- Aislamiento
- Transacciones
- Recuperación rápida

**Objetivo**: Dar libertad operativa máxima SIN perder capacidad de recuperación.

El sistema debe priorizar: resiliencia, reversibilidad, tolerancia al fallo, recuperación inmediata.

**Nunca asumir éxito irreversible.**
