# Guía de Integración: Workspace Engine con UI

## Visión General

El **Workspace Engine** está completamente desacoplado de la UI. La interfaz consume estados y acciones a través de hooks React y managers del core.

---

## Hooks Disponibles

### 1. `useWorkspace()`

Integra el workspace y contextos con React.

```typescript
import { useWorkspace } from "@/hooks/useWorkspace";

export function MyComponent() {
  const { workspace, activeContext, isLoading, setActiveContext, getContext } =
    useWorkspace();

  // workspace: Workspace | null
  // activeContext: WorkspaceContext | null
  // isLoading: boolean
  // setActiveContext: (path: string) => boolean
  // getContext: (path: string) => WorkspaceContext | null

  const handleContextChange = (path: string) => {
    const success = setActiveContext(path);
    if (success) {
      console.log("Contexto cambió a:", path);
    }
  };

  return (
    <div>
      <p>Contexto activo: {activeContext?.path}</p>
      <button onClick={() => handleContextChange("/src")}>
        Cambiar a /src
      </button>
    </div>
  );
}
```

### 2. `useFilesystem()`

Operaciones de archivo con transacciones automáticas.

```typescript
import { useFilesystem } from "@/hooks/useFilesystem";

export function FileEditor() {
  const { readFile, writeFile, deleteFile, isLoading, error } = useFilesystem();

  const handleSave = async (path: string, content: string) => {
    const result = await writeFile(path, content);
    if (result.success) {
      console.log("Archivo guardado:", path);
    } else {
      console.error("Error:", result.error);
      // Rollback automático ya ocurrió
    }
  };

  const handleDelete = async (path: string) => {
    const result = await deleteFile(path);
    if (result.success) {
      console.log("Archivo eliminado:", path);
    } else {
      console.error("Error:", result.error);
    }
  };

  return (
    <div>
      {isLoading && <p>Procesando...</p>}
      {error && <p style={{ color: "red" }}>Error: {error}</p>}
      {/* Componentes de editor */}
    </div>
  );
}
```

---

## Acceso Directo a Managers

Para casos más avanzados, puedes acceder directamente a los managers:

```typescript
import { coreEngine } from "@/core";

// Snapshots
const snapshots = coreEngine.snapshots.listSnapshots("/src");
await coreEngine.snapshots.rollback(snapshotId);

// Transactions
const transaction = await coreEngine.transactions.createTransaction(
  "write",
  "/src/App.tsx",
  operation
);

// Workspace
coreEngine.workspace.addFavorite("/src", "/src/components/Button.tsx");
const favorites = coreEngine.workspace.getActiveContext()?.metadata.favorites;

// Filesystem
const result = await coreEngine.filesystem.readFile("/src/App.tsx");
```

---

## Patrones de Integración

### Patrón 1: Explorer Contextual

```typescript
// components/ExplorerPanel.tsx
import { useWorkspace } from "@/hooks/useWorkspace";

export function ExplorerPanel() {
  const { activeContext, setActiveContext } = useWorkspace();

  const handleLongPress = (folderPath: string) => {
    // Long-press en carpeta → cambiar contexto raíz
    setActiveContext(folderPath);
  };

  const handleAddFavorite = (filePath: string) => {
    if (activeContext) {
      coreEngine.workspace.addFavorite(activeContext.path, filePath);
      // Actualizar UI
    }
  };

  return (
    <div>
      <h3>Contexto: {activeContext?.path}</h3>
      {/* Renderizar árbol de archivos */}
      {/* En cada carpeta: onLongPress={handleLongPress} */}
      {/* En cada archivo: onFavorite={handleAddFavorite} */}
    </div>
  );
}
```

### Patrón 2: Editor con Snapshots

```typescript
// components/FileEditor.tsx
import { useFilesystem } from "@/hooks/useFilesystem";
import { coreEngine } from "@/core";

export function FileEditor({ filePath }: { filePath: string }) {
  const [content, setContent] = useState("");
  const { writeFile, isLoading } = useFilesystem();

  const handleSave = async () => {
    const result = await writeFile(filePath, content);
    if (result.success) {
      // Mostrar confirmación
      const snapshots = coreEngine.snapshots.listSnapshots(filePath);
      console.log("Snapshots disponibles:", snapshots);
    }
  };

  const handleRollback = async (snapshotId: string) => {
    const success = await coreEngine.snapshots.rollback(snapshotId);
    if (success) {
      // Recargar contenido del archivo
      // setContent(...)
    }
  };

  return (
    <div>
      <textarea value={content} onChange={(e) => setContent(e.target.value)} />
      <button onClick={handleSave} disabled={isLoading}>
        {isLoading ? "Guardando..." : "Guardar"}
      </button>
      {/* Mostrar snapshots disponibles */}
      {/* En cada snapshot: onClick={() => handleRollback(snapshotId)} */}
    </div>
  );
}
```

### Patrón 3: Panel Dinámico

```typescript
// components/PanelManager.tsx
import { useWorkspace } from "@/hooks/useWorkspace";
import { coreEngine } from "@/core";

export function PanelManager() {
  const { workspace } = useWorkspace();

  const handleAddPanel = (type: "editor" | "chat" | "explorer" | "preview") => {
    const panel = {
      id: `panel_${Date.now()}`,
      type,
      canMove: true,
      canClose: true,
      canFocus: true,
    };
    coreEngine.workspace.addPanel(panel);
  };

  const handleRemovePanel = (panelId: string) => {
    coreEngine.workspace.removePanel(panelId);
  };

  const handleUpdatePanel = (panelId: string, updates: any) => {
    coreEngine.workspace.updatePanel(panelId, updates);
  };

  return (
    <div>
      {workspace?.panels.map((panel) => (
        <div key={panel.id}>
          {/* Renderizar panel */}
          <button onClick={() => handleRemovePanel(panel.id)}>Cerrar</button>
        </div>
      ))}
      <button onClick={() => handleAddPanel("editor")}>Agregar Editor</button>
    </div>
  );
}
```

---

## Flujos Comunes

### Flujo 1: Cambiar Contexto Raíz

```
Usuario hace long-press en carpeta
    ↓
ExplorerPanel llama setActiveContext(folderPath)
    ↓
WorkspaceManager actualiza activeContextPath
    ↓
Se notifica a todos los listeners
    ↓
useWorkspace() hook actualiza estado
    ↓
Componentes se re-renderizan con nuevo contexto
    ↓
Chat se contextualiza automáticamente
    ↓
Archivos recientes se filtran
    ↓
Paneles se actualizan
```

### Flujo 2: Guardar Archivo

```
Usuario edita archivo y presiona Guardar
    ↓
FileEditor llama writeFile(path, content)
    ↓
FilesystemManager valida formato
    ↓
TransactionManager crea transacción
    ↓
SnapshotManager crea snapshot automático
    ↓
TransactionManager simula en sandbox
    ↓
Si simulación exitosa:
    ├─ Ejecuta operación
    ├─ Confirma transacción
    └─ Retorna success: true
    ↓
Si falla en cualquier paso:
    ├─ Rollback automático
    └─ Retorna success: false
```

### Flujo 3: Eliminar Archivo

```
Usuario selecciona archivo y presiona Eliminar
    ↓
FileManager llama deleteFile(path)
    ↓
TransactionManager crea transacción
    ↓
SnapshotManager crea snapshot automático
    ↓
TransactionManager simula eliminación
    ↓
Si simulación exitosa:
    ├─ Ejecuta eliminación
    ├─ Confirma transacción
    └─ Retorna success: true
    ↓
Usuario ve opción de Deshacer
    ↓
Si usuario presiona Deshacer:
    ├─ SnapshotManager.rollback(snapshotId)
    └─ Archivo se restaura automáticamente
```

---

## Consideraciones de Rendimiento

### 1. Memoización

Usa `useMemo` y `useCallback` para evitar re-renders innecesarios:

```typescript
const memoizedContext = useMemo(() => activeContext, [activeContext?.path]);

const handleContextChange = useCallback((path: string) => {
  setActiveContext(path);
}, []);
```

### 2. Lazy Loading

Carga contextos bajo demanda:

```typescript
const handleContextChange = async (path: string) => {
  // Cargar contexto si no existe
  if (!coreEngine.workspace.getContext(path)) {
    const context = await loadContextFromServer(path);
    coreEngine.workspace.registerContext(path, context);
  }
  setActiveContext(path);
};
```

### 3. Debouncing

Debounce operaciones frecuentes:

```typescript
import { useCallback, useRef } from "react";

const debounce = (fn: Function, delay: number) => {
  let timeoutId: NodeJS.Timeout;
  return (...args: any[]) => {
    clearTimeout(timeoutId);
    timeoutId = setTimeout(() => fn(...args), delay);
  };
};

const debouncedSave = useCallback(
  debounce((content: string) => writeFile(filePath, content), 500),
  [filePath, writeFile]
);
```

---

## Testing

### Testing de Hooks

```typescript
import { renderHook, act } from "@testing-library/react";
import { useWorkspace } from "@/hooks/useWorkspace";

test("useWorkspace cambia contexto", () => {
  const { result } = renderHook(() => useWorkspace());

  act(() => {
    result.current.setActiveContext("/src");
  });

  expect(result.current.activeContext?.path).toBe("/src");
});
```

### Testing de Managers

```typescript
import { workspaceManager } from "@/core";

test("WorkspaceManager cambia contexto", () => {
  workspaceManager.initializeWorkspace("test", "Test", "/");
  workspaceManager.registerContext("/src", { path: "/src", name: "src", files: [] });

  const success = workspaceManager.setActiveContext("/src");
  expect(success).toBe(true);
  expect(workspaceManager.getActiveContext()?.path).toBe("/src");
});
```

---

## Próximas Etapas

1. **Persistencia Real**: Conectar snapshots con backend
2. **Conversaciones por Nodo**: Implementar `.ai.md` local
3. **Editor con Modos**: Agregar modos de edición
4. **Integración IA**: Conectar con APIs de IA
5. **Sincronización**: Sincronizar cambios en tiempo real

---

## Recursos

- `CORE_ARCHITECTURE.md` - Documentación del núcleo
- `/core/types.ts` - Definiciones de tipos
- `/hooks/useWorkspace.ts` - Hook de workspace
- `/hooks/useFilesystem.ts` - Hook de filesystem
