# Autenticación por Email - Log Completo

**Fecha**: 27 de Mayo de 2026  
**Versión**: Arkitectgr v2.2 - Email Authentication  
**Estado**: ✓ Completado

---

## Resumen

Se implementó **autenticación por email con confirmación**. Usuario ingresa email, recibe enlace de confirmación, hace clic y queda logueado. Sesión se guarda en localStorage. Rutas protegidas con `useAuth` hook.

---

## Flujo de Autenticación

```
1. Usuario abre app
   ↓
2. ¿Está autenticado?
   ├─ SÍ: Redirige a Home
   └─ NO: Redirige a LoginPage
   ↓
3. Usuario ingresa email
   ↓
4. Hace clic en "Enviar confirmación"
   ├─ Frontend: POST /api/auth/send-confirmation
   ├─ Backend: Genera token + guarda en memoria
   ├─ Backend: TODO - Envía email con enlace
   └─ Frontend: Muestra "Revisa tu email"
   ↓
5. Usuario hace clic en enlace del email
   ├─ URL: /login?token=xxxxx
   ├─ Frontend: Detecta token en URL
   ├─ Frontend: POST /api/auth/confirm-email
   ├─ Backend: Valida token
   ├─ Backend: Crea sesión
   └─ Backend: Devuelve { user, token, expiresAt }
   ↓
6. Frontend guarda sesión en localStorage
   ↓
7. Frontend redirige a Home
   ↓
8. Usuario logueado ✓
```

---

## Componentes Creados

### 1. AuthManager (core/auth.ts)

**Responsabilidades**:
- Gestionar sesión en localStorage
- Validar expiración de token
- Notificar cambios de sesión
- Logout

**API Pública**:
```typescript
class AuthManager {
  loadSession(): AuthSession | null
  saveSession(session: AuthSession): void
  getSession(): AuthSession | null
  getUser(): User | null
  getToken(): string | null
  isAuthenticated(): boolean
  clearSession(): void
  onSessionChange(callback: (session: AuthSession | null) => void): () => void
}
```

### 2. LoginPage (pages/LoginPage.tsx)

**Responsabilidades**:
- Mostrar formulario de email
- Enviar email de confirmación
- Mostrar estado "Revisa tu email"
- Procesar token de confirmación desde URL
- Redirigir a Home al confirmar

**Estados**:
- `email`: Formulario para ingresar email
- `confirmation`: Esperando confirmación
- `loading`: Procesando confirmación

### 3. useAuth Hook (hooks/useAuth.ts)

**Responsabilidades**:
- Cargar sesión al montar
- Exponer estado de autenticación
- Suscribirse a cambios de sesión
- Logout

**API**:
```typescript
function useAuth(): UseAuthReturn {
  user: User | null
  isAuthenticated: boolean
  isLoading: boolean
  logout: () => void
}
```

### 4. Auth Routes (server/auth.ts)

**Endpoints**:
- `POST /api/auth/send-confirmation` - Enviar email
- `POST /api/auth/confirm-email` - Confirmar y crear sesión

### 5. App.tsx Actualizado

**Cambios**:
- Importa `useAuth` hook
- Protege rutas con `isAuthenticated`
- Muestra loading mientras carga sesión
- Redirige no autenticados a LoginPage

---

## Tipos de Datos

### User
```typescript
interface User {
  id: string;              // user_1234567890
  email: string;           // usuario@email.com
  name: string;            // usuario (extraído de email)
  confirmedAt: number;     // timestamp
  createdAt: number;       // timestamp
}
```

### AuthSession
```typescript
interface AuthSession {
  user: User;
  token: string;           // Token de sesión
  expiresAt: number;       // Timestamp de expiración
}
```

---

## Endpoints Backend

### 1. POST /api/auth/send-confirmation

**Request**:
```json
{
  "email": "usuario@email.com"
}
```

**Response** (desarrollo):
```json
{
  "message": "Email de confirmación enviado",
  "token": "abc123def456..."
}
```

**Response** (producción):
```json
{
  "message": "Email de confirmación enviado"
}
```

**Validaciones**:
- Email requerido
- Email válido (regex)
- Genera token único
- Expira en 24 horas

### 2. POST /api/auth/confirm-email

**Request**:
```json
{
  "token": "abc123def456..."
}
```

**Response**:
```json
{
  "session": {
    "user": {
      "id": "user_1234567890",
      "email": "usuario@email.com",
      "name": "usuario",
      "confirmedAt": 1234567890000,
      "createdAt": 1234567890000
    },
    "token": "session_token_xyz...",
    "expiresAt": 1234567890000
  }
}
```

**Validaciones**:
- Token requerido
- Token existe en pendingConfirmations
- Token no ha expirado
- Crea sesión con 30 días de duración

---

## Flujo en Frontend

### LoginPage.tsx

```typescript
// Paso 1: Usuario ingresa email
const handleSendEmail = async (e: React.FormEvent) => {
  const response = await fetch("/api/auth/send-confirmation", {
    method: "POST",
    body: JSON.stringify({ email }),
  });
  setStep("confirmation");
};

// Paso 2: Detectar token en URL
const params = new URLSearchParams(window.location.search);
const confirmToken = params.get("token");

if (confirmToken) {
  handleConfirmEmail(confirmToken);
}

// Paso 3: Confirmar email
const handleConfirmEmail = async (token: string) => {
  const response = await fetch("/api/auth/confirm-email", {
    method: "POST",
    body: JSON.stringify({ token }),
  });
  const { session } = await response.json();
  localStorage.setItem("auth_session", JSON.stringify(session));
  setLocation("/"); // Redirigir a Home
};
```

### useAuth Hook

```typescript
export function useAuth(): UseAuthReturn {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  // Cargar sesión al montar
  useEffect(() => {
    const session = authManager.loadSession();
    setUser(session?.user ?? null);
    setIsLoading(false);

    // Suscribirse a cambios
    const unsubscribe = authManager.onSessionChange((session) => {
      setUser(session?.user ?? null);
    });

    return unsubscribe;
  }, []);

  return {
    user,
    isAuthenticated: !!user,
    isLoading,
    logout: () => authManager.clearSession(),
  };
}
```

### App.tsx

```typescript
function Router() {
  const { isAuthenticated, isLoading } = useAuth();

  if (isLoading) {
    return <LoadingScreen />;
  }

  return (
    <Switch>
      <Route path={"/login"} component={LoginPage} />
      <Route
        path={"/"}
        component={() => (isAuthenticated ? <Home /> : <LoginPage />)}
      />
    </Switch>
  );
}
```

---

## Almacenamiento de Sesión

### localStorage

```json
{
  "auth_session": {
    "user": {
      "id": "user_1234567890",
      "email": "usuario@email.com",
      "name": "usuario",
      "confirmedAt": 1234567890000,
      "createdAt": 1234567890000
    },
    "token": "session_token_xyz...",
    "expiresAt": 1234567890000
  }
}
```

**Ventajas**:
- ✓ Persiste entre recargas
- ✓ No se pierde al cerrar navegador
- ✓ Accesible desde cualquier pestaña

**Seguridad**:
- ✓ Token en localStorage (no en cookies)
- ✓ Validación de expiración
- ✓ Logout limpia localStorage

---

## Próximos Pasos

### Corto Plazo
1. **Integrar servicio de email** - SendGrid, Resend, etc.
2. **Guardar usuarios en Supabase** - Persistencia real
3. **Agregar logout button** - En Home.tsx

### Mediano Plazo
1. **Recuperación de contraseña** - Enlace para reset
2. **Cambio de email** - Verificación de nuevo email
3. **Perfil de usuario** - Editar nombre, foto, etc.

### Largo Plazo
1. **Two-factor authentication** - Código OTP
2. **Sesiones múltiples** - Dispositivos diferentes
3. **Auditoría de login** - Historial de accesos

---

## Configuración de Email (TODO)

Para enviar emails reales, necesitas:

### Opción 1: SendGrid
```typescript
import sgMail from "@sendgrid/mail";

sgMail.setApiKey(process.env.SENDGRID_API_KEY);

await sgMail.send({
  to: email,
  from: "noreply@arquitecto.com",
  subject: "Confirma tu email",
  html: `<a href="${confirmationLink}">Confirmar</a>`,
});
```

### Opción 2: Resend
```typescript
import { Resend } from "resend";

const resend = new Resend(process.env.RESEND_API_KEY);

await resend.emails.send({
  from: "noreply@arquitecto.com",
  to: email,
  subject: "Confirma tu email",
  html: `<a href="${confirmationLink}">Confirmar</a>`,
});
```

### Opción 3: Supabase Auth
```typescript
const { data, error } = await supabase.auth.signInWithOtp({
  email,
  options: {
    emailRedirectTo: confirmationLink,
  },
});
```

---

## Validación

✓ AuthManager implementado  
✓ LoginPage con formulario de email  
✓ useAuth hook para proteger rutas  
✓ Endpoints /api/auth/send-confirmation y /api/auth/confirm-email  
✓ App.tsx protege Home  
✓ Sesión persiste en localStorage  
✓ Validación de expiración  
✓ TypeScript compila sin errores  

---

**Fin del Log de Autenticación por Email**
