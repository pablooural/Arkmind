# Guía de Implementación - UX Arquitecto

Este documento proporciona una guía paso a paso para completar la implementación del esqueleto desacoplado.

## Módulos por Implementar

### 1. ColorWheel.tsx ⭐ PRIORIDAD ALTA

**Ubicación:** `client/src/components/ColorWheel.tsx`

**Qué implementar:**
- Dibujar rueda de colores HSV en canvas
- Manejar clicks y drags en la rueda
- Implementar slider de brillo
- Mostrar preview del color en Hex

**Dependencias:**
- `hexToHsv()` y `hsvToHex()` de `utils/colorConversion.ts`

**Interfaz esperada:**
```tsx
interface ColorWheelProps {
  color: string;           // Color actual en Hex
  onChange: (color: string) => void;  // Callback al cambiar
}
```

**Puntos clave:**
- El canvas debe ser redimensionable
- Soportar mouse y touch
- Mostrar cursor visual en la rueda
- Actualizar en tiempo real

---

### 2. ChatPanel.tsx ⭐ PRIORIDAD ALTA

**Ubicación:** `client/src/components/ChatPanel.tsx`

**Qué implementar:**
- Lógica de envío de mensajes
- Conexión con API de IA
- Manejo de estados de carga
- Scroll automático al nuevo mensaje

**Dependencias:**
- API de IA (Claude, OpenAI, etc.)
- Hook `useRef` para scroll

**Interfaz esperada:**
```tsx
interface ChatPanelProps {
  theme: Theme;  // Tema actual
}
```

**Puntos clave:**
- Validar input antes de enviar
- Mostrar indicador de carga
- Manejar errores de conexión
- Mantener historial de mensajes
- Auto-scroll al nuevo mensaje

**Ejemplo de implementación:**
```tsx
const send = async () => {
  const text = input.trim();
  if (!text || loading) return;

  // Agregar mensaje del usuario
  const newMessages = [...messages, { role: "user", text }];
  setMessages(newMessages);
  setInput("");
  setLoading(true);

  try {
    // Llamar a API
    const response = await fetch("/api/chat", {
      method: "POST",
      body: JSON.stringify({ messages: newMessages }),
    });
    
    const data = await response.json();
    
    // Agregar respuesta
    setMessages([...newMessages, { role: "assistant", text: data.reply }]);
  } catch (error) {
    setMessages([...newMessages, { role: "assistant", text: "Error" }]);
  } finally {
    setLoading(false);
  }
};
```

---

### 3. FileExplorer.tsx ⭐ PRIORIDAD ALTA

**Ubicación:** `client/src/components/FileExplorer.tsx`

**Qué implementar:**
- Estructura de datos de archivos/carpetas
- Navegación con breadcrumb
- Selección de archivos
- Mostrar información de archivo

**Dependencias:**
- Estructura de datos (tree, lista, etc.)

**Interfaz esperada:**
```tsx
interface FileExplorerProps {
  theme: Theme;  // Tema actual
}
```

**Estructura de datos sugerida:**
```tsx
interface FileNode {
  type: "file" | "folder";
  name: string;
  ext?: string;      // Extensión (solo para archivos)
  size?: string;     // Tamaño (solo para archivos)
  children?: FileNode[];  // Hijos (solo para carpetas)
}
```

**Puntos clave:**
- Ordenar carpetas primero, luego archivos
- Mostrar iconos según tipo de archivo
- Breadcrumb interactivo
- Información al seleccionar archivo
- Botón "atrás" para subir de carpeta

---

### 4. ConfigMenu.tsx (Parcial)

**Ubicación:** `client/src/components/ConfigMenu.tsx`

**Qué completar:**
- Conectar ColorWheel con selector de colores
- Implementar secciones placeholder (Perfil, Cuenta, Notificaciones)

**Puntos clave:**
- El modal de ColorWheel ya está estructurado
- Solo falta conectar la lógica de ColorWheel
- Las secciones placeholder pueden quedar como "próximamente"

---

### 5. Otros Componentes (Menores)

**ResizableDivider.tsx** - ✅ Completado
**SplitView.tsx** - ✅ Completado
**SlideModeView.tsx** - ✅ Completado
**DualPanelLayout.tsx** - ✅ Completado

---

## Orden de Implementación Recomendado

1. **ColorWheel.tsx** - Base para personalización de colores
2. **FileExplorer.tsx** - Panel B (más independiente)
3. **ChatPanel.tsx** - Panel A (requiere API externa)
4. **ConfigMenu.tsx** - Integración final

---

## Testing Local

### Verificar que todo compila
```bash
pnpm dev
```

### Verificar tipos TypeScript
```bash
pnpm check
```

### Acceder a la aplicación
```
http://localhost:3000
```

---

## Checklist de Implementación

### ColorWheel
- [ ] Canvas dibuja rueda de colores
- [ ] Click en rueda actualiza color
- [ ] Drag en rueda funciona
- [ ] Slider de brillo funciona
- [ ] Preview de color se actualiza
- [ ] Soporta touch

### ChatPanel
- [ ] Envío de mensajes funciona
- [ ] API conectada
- [ ] Indicador de carga visible
- [ ] Scroll automático funciona
- [ ] Manejo de errores

### FileExplorer
- [ ] Estructura de datos implementada
- [ ] Navegación funciona
- [ ] Breadcrumb interactivo
- [ ] Selección de archivos
- [ ] Información de archivo visible

### ConfigMenu
- [ ] ColorWheel conectado
- [ ] Cambio de paleta funciona
- [ ] Cambio de color individual funciona
- [ ] Modal se abre/cierra correctamente

---

## Ejemplos de Código

### Usar ColorSystem
```tsx
import { COLOR_PRESETS, getDefaultTheme } from "@/utils/colorSystem";

const theme = getDefaultTheme();  // Obtener tema por defecto
const preset = COLOR_PRESETS[0];  // Acceder a paleta específica
```

### Usar Conversión de Colores
```tsx
import { hexToHsv, hsvToHex } from "@/utils/colorConversion";

const hsv = hexToHsv("#fbbf24");
const hex = hsvToHex({ h: 45, s: 100, v: 98 });
```

### Crear Componente con Tema
```tsx
import { Theme } from "@/types/theme";

interface MyComponentProps {
  theme: Theme;
}

export function MyComponent({ theme }: MyComponentProps) {
  return (
    <div style={{ background: theme.bg, color: theme.text }}>
      Contenido
    </div>
  );
}
```

---

## Recursos Útiles

- **Canvas API:** https://developer.mozilla.org/es/docs/Web/API/Canvas_API
- **React Hooks:** https://react.dev/reference/react
- **TypeScript:** https://www.typescriptlang.org/docs/

---

## Preguntas Frecuentes

**P: ¿Dónde guardo los datos del FileExplorer?**
R: Puedes usar `useState` para estado local, o conectar con una API backend.

**P: ¿Cómo conecto ChatPanel con una API?**
R: Usa `fetch()` o una librería como `axios`. Mira el ejemplo en la sección de ChatPanel.

**P: ¿Puedo agregar más paletas de color?**
R: Sí, agrega más objetos al array `COLOR_PRESETS` en `utils/colorSystem.ts`.

**P: ¿Cómo hago que los cambios de tema se guarden?**
R: Usa `localStorage` en DualPanelLayout para persistir el tema.

---

## Soporte

Si tienes dudas sobre la arquitectura o necesitas ayuda con la implementación, revisa:
1. `ARCHITECTURE.md` - Descripción general
2. Comentarios `// TODO` en el código
3. Interfaces de tipos en `types/theme.ts`
