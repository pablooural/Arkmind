/**
 * AI API Service
 * Cliente para comunicarse con el backend seguro
 * Las claves API están en el servidor, no en el frontend
 */

export interface AIConfigResponse {
  mistral: {
    model: string;
    temperature: number;
    maxTokens: number;
  };
  supabase: {
    url: string;
  };
  configured: boolean;
}

export interface AIMessageResponse {
  content: string;
}

/**
 * Obtener configuración de IA desde el backend
 * Las claves API NO se exponen al frontend
 */
export async function getAIConfig(): Promise<AIConfigResponse> {
  try {
    const response = await fetch("/api/ai-config");

    if (!response.ok) {
      throw new Error(`Error: ${response.statusText}`);
    }

    return await response.json();
  } catch (error) {
    console.error("Error obteniendo configuración de IA:", error);
    throw error;
  }
}

/**
 * Enviar mensaje a Mistral AI a través del backend
 * El backend maneja la autenticación con Mistral
 */
export async function sendMessageToAI(message: string, model?: string): Promise<string> {
  try {
    const response = await fetch("/api/ai/message", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        message,
        model,
      }),
    });

    if (!response.ok) {
      const error = await response.json();
      throw new Error(error.error || "Error enviando mensaje");
    }

    const data: AIMessageResponse = await response.json();
    return data.content;
  } catch (error) {
    console.error("Error enviando mensaje a IA:", error);
    throw error;
  }
}
