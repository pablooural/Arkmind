/**
 * Home Page
 * Inicializa el workspace y renderiza DualPanelLayout
 * 
 * CAMBIOS CAPA 6:
 * - Inicializa workspace con workspaceManager
 * - Crea sesión IA inicial
 * - Configura contextos cognitivos y visuales
 * - Agrega logout button y user info
 */

import { useEffect } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/hooks/useAuth";
import { workspaceManager, sessionManager, cognitiveManager, visualManager } from "@/core";
import DualPanelLayout from "./DualPanelLayout";

export default function Home() {
  const [, setLocation] = useLocation();
  const { user, logout } = useAuth();

  const handleLogout = () => {
    logout();
    setLocation("/login");
  };

  useEffect(() => {
    // Inicializar workspace
    const workspace = workspaceManager.initializeWorkspace(
      "workspace_main",
      "UX Arquitecto",
      "/home/user/projects"
    );

    // Crear contexto cognitivo para la ruta raíz
    const cognitiveContext = cognitiveManager.createContext("/home/user/projects", "architecture");

    // Crear contexto visual para panel de chat
    const visualContext = visualManager.createContext("panel_chat", "/home/user/projects");

    // Crear sesión IA inicial
    const session = sessionManager.createSession(
      "panel_chat",
      "/home/user/projects",
      cognitiveContext,
      visualContext
    );

    // Adjuntar sesión al workspace
    workspaceManager.attachSession("panel_chat", session);

    console.log("✓ Workspace inicializado:", workspace);
    console.log("✓ Sesión IA creada:", session.id);
    console.log("✓ Contexto cognitivo creado:", cognitiveContext.goal);
    console.log("✓ Contexto visual creado");

    // Agregar algunos insights iniciales
    cognitiveManager.addInsight(
      "/home/user/projects",
      "Arquitectura desacoplada con 7 managers: snapshots, transactions, workspace, filesystem, session, cognitive, visual",
      ["CORE_ARCHITECTURE.md"],
      5
    );

    cognitiveManager.addQuestion(
      "/home/user/projects",
      "¿Cómo integrar las APIs de IA con el SessionManager?",
      ["client/src/core/session.ts"],
      4
    );

    return () => {
      // Cleanup si es necesario
      sessionManager.destroySession(session.id);
      cognitiveManager.clearContext("/home/user/projects");
      visualManager.clearContext("panel_chat");
    };
  }, []);

  return (
    <div style={{ position: "relative", width: "100%", height: "100vh" }}>
      {/* User Info + Logout */}
      <div
        style={{
          position: "absolute",
          top: "1rem",
          right: "1rem",
          zIndex: 1000,
          display: "flex",
          alignItems: "center",
          gap: "1rem",
          background: "rgba(15, 23, 42, 0.8)",
          padding: "0.5rem 1rem",
          borderRadius: "8px",
          border: "1px solid rgba(255, 255, 255, 0.1)",
          backdropFilter: "blur(16px)",
        }}
      >
        <span
          style={{
            fontSize: "0.85rem",
            color: "#94a3b8",
            fontFamily: "'Courier New', monospace",
          }}
        >
          {user?.email}
        </span>
        <button
          onClick={handleLogout}
          style={{
            padding: "0.4rem 0.8rem",
            background: "#ff6b6b",
            color: "#fff",
            border: "none",
            borderRadius: "6px",
            cursor: "pointer",
            fontSize: "0.8rem",
            fontWeight: "600",
            transition: "all 0.2s",
          }}
          onMouseEnter={(e) => {
            e.currentTarget.style.opacity = "0.9";
          }}
          onMouseLeave={(e) => {
            e.currentTarget.style.opacity = "1";
          }}
        >
          Salir
        </button>
      </div>

      {/* Main Layout */}
      <DualPanelLayout />
    </div>
  );
}
