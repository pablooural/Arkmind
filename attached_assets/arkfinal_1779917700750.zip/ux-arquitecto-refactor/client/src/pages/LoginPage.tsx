/**
 * LoginPage
 * Página de autenticación por email
 * 
 * Flujo:
 * 1. Usuario ingresa email
 * 2. Se envía email de confirmación
 * 3. Usuario hace clic en enlace
 * 4. Se confirma y redirige a Home
 */

import { useState } from "react";
import { useLocation } from "wouter";

type LoginStep = "email" | "confirmation" | "loading";

export default function LoginPage() {
  const [, setLocation] = useLocation();
  const [step, setStep] = useState<LoginStep>("email");
  const [email, setEmail] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  /**
   * Paso 1: Enviar email de confirmación
   */
  const handleSendEmail = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim()) {
      setError("Por favor ingresa un email");
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const response = await fetch("/api/auth/send-confirmation", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email }),
      });

      if (!response.ok) {
        const data = await response.json();
        throw new Error(data.error || "Error enviando email");
      }

      setStep("confirmation");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Error enviando email");
    } finally {
      setLoading(false);
    }
  };

  /**
   * Paso 2: Confirmar email (desde enlace en email)
   */
  const handleConfirmEmail = async (token: string) => {
    setLoading(true);
    setError(null);

    try {
      const response = await fetch("/api/auth/confirm-email", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ token }),
      });

      if (!response.ok) {
        const data = await response.json();
        throw new Error(data.error || "Error confirmando email");
      }

      const { session } = await response.json();

      // Guardar sesión
      localStorage.setItem("auth_session", JSON.stringify(session));

      // Redirigir a Home
      setLocation("/");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Error confirmando email");
    } finally {
      setLoading(false);
    }
  };

  // Verificar si hay token de confirmación en URL
  const params = new URLSearchParams(window.location.search);
  const confirmToken = params.get("token");

  if (confirmToken && step === "email") {
    handleConfirmEmail(confirmToken);
  }

  return (
    <div
      style={{
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        minHeight: "100vh",
        background: "linear-gradient(135deg, #0f172a 0%, #1e293b 100%)",
        fontFamily: "Georgia, serif",
      }}
    >
      <div
        style={{
          width: "100%",
          maxWidth: "400px",
          padding: "2rem",
          background: "rgba(15, 23, 42, 0.8)",
          border: "1px solid rgba(255, 255, 255, 0.1)",
          borderRadius: "12px",
          backdropFilter: "blur(16px)",
        }}
      >
        {/* Header */}
        <div style={{ textAlign: "center", marginBottom: "2rem" }}>
          <h1
            style={{
              fontSize: "1.8rem",
              color: "#fff",
              margin: "0 0 0.5rem 0",
              fontWeight: "600",
            }}
          >
            UX Arquitecto
          </h1>
          <p style={{ fontSize: "0.9rem", color: "#94a3b8", margin: 0 }}>
            Ingresa con tu email
          </p>
        </div>

        {/* Paso 1: Email */}
        {step === "email" && (
          <form onSubmit={handleSendEmail} style={{ display: "flex", flexDirection: "column", gap: "1rem" }}>
            <div>
              <label
                style={{
                  display: "block",
                  fontSize: "0.85rem",
                  color: "#cbd5e1",
                  marginBottom: "0.5rem",
                  fontFamily: "'Courier New', monospace",
                }}
              >
                Email
              </label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="tu@email.com"
                style={{
                  width: "100%",
                  padding: "0.75rem",
                  background: "rgba(255, 255, 255, 0.05)",
                  border: "1px solid rgba(255, 255, 255, 0.1)",
                  borderRadius: "8px",
                  color: "#fff",
                  fontSize: "0.95rem",
                  boxSizing: "border-box",
                }}
              />
            </div>

            {error && (
              <div
                style={{
                  padding: "0.75rem",
                  background: "#ff6b6b30",
                  border: "1px solid #ff6b6b44",
                  borderRadius: "8px",
                  color: "#ff6b6b",
                  fontSize: "0.85rem",
                }}
              >
                {error}
              </div>
            )}

            <button
              type="submit"
              disabled={loading}
              style={{
                padding: "0.75rem",
                background: "#4ade80",
                color: "#000",
                border: "none",
                borderRadius: "8px",
                cursor: loading ? "not-allowed" : "pointer",
                fontSize: "0.95rem",
                fontWeight: "600",
                opacity: loading ? 0.7 : 1,
                transition: "all 0.2s",
              }}
            >
              {loading ? "Enviando..." : "Enviar confirmación"}
            </button>
          </form>
        )}

        {/* Paso 2: Confirmación */}
        {step === "confirmation" && (
          <div style={{ textAlign: "center" }}>
            <div
              style={{
                fontSize: "3rem",
                marginBottom: "1rem",
              }}
            >
              ✉️
            </div>
            <p style={{ color: "#cbd5e1", marginBottom: "1rem" }}>
              Hemos enviado un enlace de confirmación a:
            </p>
            <p
              style={{
                color: "#4ade80",
                fontFamily: "'Courier New', monospace",
                fontSize: "0.9rem",
                marginBottom: "1.5rem",
              }}
            >
              {email}
            </p>
            <p style={{ color: "#94a3b8", fontSize: "0.85rem", marginBottom: "1rem" }}>
              Haz clic en el enlace del email para confirmar tu cuenta.
            </p>
            <button
              onClick={() => {
                setStep("email");
                setEmail("");
                setError(null);
              }}
              style={{
                padding: "0.5rem 1rem",
                background: "rgba(255, 255, 255, 0.1)",
                color: "#94a3b8",
                border: "1px solid rgba(255, 255, 255, 0.2)",
                borderRadius: "6px",
                cursor: "pointer",
                fontSize: "0.85rem",
              }}
            >
              ← Volver
            </button>
          </div>
        )}

        {/* Paso 3: Cargando */}
        {step === "loading" && (
          <div style={{ textAlign: "center" }}>
            <div
              style={{
                fontSize: "2rem",
                animation: "spin 1s linear infinite",
                marginBottom: "1rem",
              }}
            >
              ⏳
            </div>
            <p style={{ color: "#cbd5e1" }}>Confirmando tu email...</p>
          </div>
        )}

        {/* Footer */}
        <div
          style={{
            marginTop: "2rem",
            paddingTop: "1.5rem",
            borderTop: "1px solid rgba(255, 255, 255, 0.1)",
            textAlign: "center",
            fontSize: "0.8rem",
            color: "#64748b",
          }}
        >
          <p style={{ margin: 0 }}>
            Al continuar, aceptas nuestros{" "}
            <span style={{ color: "#94a3b8", cursor: "pointer" }}>términos de servicio</span>
          </p>
        </div>
      </div>

      <style>{`
        @keyframes spin {
          from { transform: rotate(0deg); }
          to { transform: rotate(360deg); }
        }
      `}</style>
    </div>
  );
}
