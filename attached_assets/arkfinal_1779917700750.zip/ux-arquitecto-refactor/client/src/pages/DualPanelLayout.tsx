/**
 * DualPanelLayout
 * Componente principal que orquesta todos los módulos
 * 
 * Modos de vista:
 * - slide: Panel lateral deslizable
 * - split-v: División vertical
 * - split-h: División horizontal
 */

import { useState } from "react";
import { Theme } from "@/types/theme";
import { COLOR_PRESETS, getDefaultTheme } from "@/utils/colorSystem";
import { ConfigMenu } from "@/components/ConfigMenu";
import { ChatPanel } from "@/components/ChatPanel";
import { FileExplorer } from "@/components/FileExplorer";
import { SplitView } from "@/components/SplitView";
import { SlideModeView } from "@/components/SlideModeView";

type LayoutMode = "slide" | "split-v" | "split-h";

export default function DualPanelLayout() {
  // Estado de layout
  const [mode, setMode] = useState<LayoutMode>("slide");
  const [sideOpen, setSideOpen] = useState(false);
  const [swapped, setSwapped] = useState(false);
  const [flipping, setFlipping] = useState(false);

  // Estado de tema
  const [configOpen, setConfigOpen] = useState(false);
  const [theme, setTheme] = useState<Theme>(getDefaultTheme());

  // Manejadores
  const handleSwap = () => {
    if (flipping) return;
    setFlipping(true);
    setTimeout(() => {
      setSwapped((s) => !s);
      setFlipping(false);
    }, 420);
  };

  // Contenido de paneles
  const fixedContent = swapped ? <FileExplorer theme={theme} /> : <ChatPanel theme={theme} sessionId={null} />;
  const sideContent = swapped ? <ChatPanel theme={theme} sessionId={null} /> : <FileExplorer theme={theme} />;

  // Estilos de botones
  const btn = (active: boolean) => ({
    display: "flex" as const,
    alignItems: "center" as const,
    justifyContent: "center" as const,
    width: "40px",
    height: "40px",
    borderRadius: "9px",
    border: active ? `1px solid ${theme.accent}88` : "1px solid rgba(255,255,255,0.1)",
    background: active ? `${theme.accent}22` : "rgba(255,255,255,0.05)",
    color: active ? theme.accent : "#94a3b8",
    cursor: "pointer",
    fontSize: "16px",
    transition: "all 0.18s",
    userSelect: "none" as const,
    flexShrink: 0,
    WebkitTapHighlightColor: "transparent",
  });

  return (
    <div
      style={{
        width: "100vw",
        height: "100vh",
        background: `linear-gradient(135deg, ${theme.bg} 0%, ${theme.surface} 55%, ${theme.bg} 100%)`,
        display: "flex",
        flexDirection: "column",
        overflow: "hidden",
        fontFamily: "'Courier New', monospace",
        transition: "background 0.4s",
      }}
    >
      {/* TOP BAR */}
      <div
        style={{
          height: "54px",
          flexShrink: 0,
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          padding: "0 0.9rem",
          borderBottom: "1px solid rgba(255,255,255,0.07)",
          background: "rgba(0,0,0,0.35)",
          backdropFilter: "blur(12px)",
        }}
      >
        {/* Botón menú */}
        <button
          onClick={() => setConfigOpen(true)}
          style={{
            ...btn(configOpen),
            fontSize: "18px",
            letterSpacing: "-1px",
          }}
          title="Configuración"
        >
          ≡
        </button>

        {/* Botones de control */}
        <div style={{ display: "flex", gap: "0.35rem" }}>
          <button
            style={{
              ...btn(false),
              transform: flipping ? "rotateY(90deg)" : "rotateY(0deg)",
              transition: "transform 0.42s ease, background 0.18s, border 0.18s, color 0.18s",
            }}
            onClick={handleSwap}
            title="Intercambiar paneles"
          >
            ⇄
          </button>
          <button
            style={btn(mode === "split-v")}
            onClick={() => setMode((m) => (m === "split-v" ? "slide" : "split-v"))}
            title="División vertical"
          >
            ▐
          </button>
          <button
            style={btn(mode === "split-h")}
            onClick={() => setMode((m) => (m === "split-h" ? "slide" : "split-h"))}
            title="División horizontal"
          >
            ▄
          </button>
        </div>
      </div>

      {/* CONTENIDO */}
      <div style={{ flex: 1, overflow: "hidden", position: "relative" }}>
        {mode === "slide" && (
          <SlideModeView
            sideOpen={sideOpen}
            setSideOpen={setSideOpen}
            sideContent={sideContent}
            fixedContent={fixedContent}
            flipping={flipping}
            theme={theme}
          />
        )}

        {mode === "split-v" && (
          <SplitView
            direction="vertical"
            accent={theme.accent}
            theme={theme}
            panelA={swapped ? <FileExplorer theme={theme} /> : <ChatPanel theme={theme} sessionId={null} />}
            panelB={swapped ? <ChatPanel theme={theme} sessionId={null} /> : <FileExplorer theme={theme} />}
          />
        )}

        {mode === "split-h" && (
          <SplitView
            direction="horizontal"
            accent={theme.accent}
            theme={theme}
            panelA={swapped ? <FileExplorer theme={theme} /> : <ChatPanel theme={theme} sessionId={null} />}
            panelB={swapped ? <ChatPanel theme={theme} sessionId={null} /> : <FileExplorer theme={theme} />}
          />
        )}
      </div>

      {/* STATUS BAR */}
      <div
        style={{
          height: "24px",
          flexShrink: 0,
          display: "flex",
          alignItems: "center",
          padding: "0 0.9rem",
          gap: "1.2rem",
          borderTop: "1px solid rgba(255,255,255,0.05)",
          background: "rgba(0,0,0,0.3)",
          fontSize: "0.6rem",
          color: "#334155",
          letterSpacing: "0.06em",
          overflow: "hidden",
        }}
      >
        <span>MODO: {mode === "slide" ? "LATERAL" : mode === "split-v" ? "DIV. VERTICAL" : "DIV. HORIZONTAL"}</span>
        {mode === "slide" && <span>{swapped ? "ARCHIVOS ◂ CHAT" : "CHAT ◂ ARCHIVOS"}</span>}
        <span style={{ marginLeft: "auto", color: theme.accent, opacity: 0.5, fontSize: "0.55rem" }}>
          ● {theme.name || "Custom"}
        </span>
      </div>

      {/* CONFIG MENU */}
      <ConfigMenu 
        open={configOpen} 
        onClose={() => setConfigOpen(false)} 
        theme={theme} 
        onThemeChange={setTheme}
      />

      {/* Estilos globales */}
      <style>{`
        * { -webkit-tap-highlight-color: transparent; }
        ::-webkit-scrollbar { width: 4px; height: 4px; }
        ::-webkit-scrollbar-thumb { background: rgba(255,255,255,0.1); border-radius: 3px; }
      `}</style>
    </div>
  );
}
