/**
 * useAI Hook
 * Integración de Mistral AI con React y SessionManager
 * 
 * NUEVO:
 * - Envía mensajes a Mistral AI
 * - Integra respuestas con SessionManager
 * - Gestiona estado de carga y errores
 */

import { useState, useCallback, useEffect } from "react";
import { aiManager, AIConfig, SupabaseConfig, MistralModel } from "@/core";
import { sessionManager } from "@/core";
import { getAIConfig, sendMessageToAI } from "@/lib/aiApi";

interface UseAIReturn {
  isConfigured: boolean;
  currentModel: MistralModel | null;
  isLoading: boolean;
  error: string | null;
  sendMessage: (sessionId: string, userMessage: string) => Promise<string | null>;
  setAIConfig: (config: AIConfig) => void;
  setSupabaseConfig: (config: SupabaseConfig) => void;
  setModel: (model: MistralModel) => boolean;
  getAvailableModels: () => Array<{ id: MistralModel; name: string; description: string }>;
  clearError: () => void;
}

export function useAI(): UseAIReturn {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isConfigured, setIsConfigured] = useState(false);
  const [currentModel, setCurrentModel] = useState<MistralModel | null>(null);

  // Cargar configuración desde el backend al montar
  useEffect(() => {
    const loadConfig = async () => {
      try {
        const config = await getAIConfig();
        setIsConfigured(config.configured);
        setCurrentModel((config.mistral.model as MistralModel) || null);
        console.log("✓ Configuración de IA cargada desde backend");
      } catch (err) {
        console.error("Error cargando configuración:", err);
        setError("No se pudo cargar la configuración de IA");
      }
    };

    loadConfig();
  }, []);

  const handleSendMessage = useCallback(
    async (sessionId: string, userMessage: string): Promise<string | null> => {
      if (!isConfigured) {
        setError("IA no está configurada en el servidor.");
        return null;
      }

      setIsLoading(true);
      setError(null);

      try {
        // 1. Agregar mensaje del usuario a la sesión
        const userMsg = sessionManager.addMessage(sessionId, {
          id: `msg_${Date.now()}`,
          role: "user",
          type: "text",
          content: userMessage,
          timestamp: Date.now(),
        });

        if (!userMsg) {
          setError("No se pudo agregar el mensaje a la sesión");
          return null;
        }

        // 2. Enviar a Mistral AI a través del backend seguro
        const aiResponse = await sendMessageToAI(userMessage, currentModel || undefined);

        if (!aiResponse) {
          setError("Error al obtener respuesta de Mistral AI");
          return null;
        }

        // 3. Agregar respuesta a la sesión
        const assistantMsg = sessionManager.addMessage(sessionId, {
          id: `msg_${Date.now()}_ai`,
          role: "assistant",
          type: "text",
          content: aiResponse,
          timestamp: Date.now(),
        });

        if (!assistantMsg) {
          setError("No se pudo agregar la respuesta a la sesión");
          return null;
        }

        return aiResponse;
      } catch (err) {
        const message = err instanceof Error ? err.message : String(err);
        setError(message);
        return null;
      } finally {
        setIsLoading(false);
      }
    },
    [isConfigured, currentModel]
  );

  const handleSetAIConfig = useCallback((config: AIConfig) => {
    aiManager.setAIConfig(config);
    setError(null);
  }, []);

  const handleSetSupabaseConfig = useCallback((config: SupabaseConfig) => {
    aiManager.setSupabaseConfig(config);
    setError(null);
  }, []);

  const handleSetModel = useCallback((model: MistralModel): boolean => {
    const success = aiManager.setModel(model);
    if (success) {
      setError(null);
    }
    return success;
  }, []);

  const handleGetAvailableModels = useCallback(() => {
    return aiManager.getAvailableModels();
  }, []);

  const handleClearError = useCallback(() => {
    setError(null);
  }, []);

  const currentConfig = aiManager.getAIConfig();

  return {
    isConfigured,
    currentModel,
    isLoading,
    error,
    sendMessage: handleSendMessage,
    setAIConfig: handleSetAIConfig,
    setSupabaseConfig: handleSetSupabaseConfig,
    setModel: handleSetModel,
    getAvailableModels: handleGetAvailableModels,
    clearError: handleClearError,
  };
}
