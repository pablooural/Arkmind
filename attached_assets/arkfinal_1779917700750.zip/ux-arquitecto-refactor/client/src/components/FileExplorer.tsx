/**
 * FileExplorer Component (Panel B)
 * Explorador de archivos con navegación jerárquica y long-press
 * 
 * CAMBIOS CAPA 6:
 * - Conectado con useWorkspace y useFilesystem
 * - Long-press para cambiar contexto raíz
 * - Renderiza FileNode[] reales
 * - Soporte para abrir/cerrar carpetas
 */

import { useState, useRef } from "react";
import { useWorkspace } from "@/hooks/useWorkspace";
import { useFilesystem } from "@/hooks/useFilesystem";
import { Theme } from "@/types/theme";
import { ChevronRight, Folder, File } from "lucide-react";

interface FileExplorerProps {
  theme: Theme;
}

export function FileExplorer({ theme }: FileExplorerProps) {
  const { activeContextPath, setActiveContext } = useWorkspace();
  const { isLoading, error } = useFilesystem();
  
  const [path, setPath] = useState<string[]>([]);
  const [selected, setSelected] = useState<string | null>(null);
  const [expanded, setExpanded] = useState<Set<string>>(new Set());
  const [longPressPath, setLongPressPath] = useState<string | null>(null);
  const longPressTimer = useRef<NodeJS.Timeout | null>(null);

  const fullPath = activeContextPath || "/";
  const currentPath = "/" + path.join("/");

  // Simulación de árbol de archivos (TODO: conectar con filesystemManager)
  const mockFiles = [
    { name: "src", type: "folder" as const, path: "/src" },
    { name: "components", type: "folder" as const, path: "/components" },
    { name: "utils", type: "folder" as const, path: "/utils" },
    { name: "package.json", type: "file" as const, path: "/package.json" },
    { name: "README.md", type: "file" as const, path: "/README.md" },
  ];

  const handleLongPressStart = (itemPath: string) => {
    longPressTimer.current = setTimeout(() => {
      setLongPressPath(itemPath);
      // Cambiar contexto raíz
      setActiveContext(itemPath);
      setPath([]);
      setSelected(null);
    }, 600);
  };

  const handleLongPressEnd = () => {
    if (longPressTimer.current) {
      clearTimeout(longPressTimer.current);
      longPressTimer.current = null;
    }
  };

  const handleFolderClick = (folderName: string) => {
    const newPath = [...path, folderName];
    setPath(newPath);
    setSelected(null);
  };

  const handleBreadcrumbClick = (index: number) => {
    setPath(path.slice(0, index + 1));
    setSelected(null);
  };

  const handleRootClick = () => {
    setPath([]);
    setSelected(null);
  };

  const toggleExpanded = (itemPath: string) => {
    const newExpanded = new Set(expanded);
    if (newExpanded.has(itemPath)) {
      newExpanded.delete(itemPath);
    } else {
      newExpanded.add(itemPath);
    }
    setExpanded(newExpanded);
  };

  return (
    <div style={{ display: "flex", flexDirection: "column", height: "100%", fontFamily: "'Courier New', monospace" }}>
      {/* Header - Contexto Raíz */}
      <div
        style={{
          padding: "0.5rem 0.9rem",
          borderBottom: `1px solid ${theme.accent}15`,
          background: `${theme.bg}cc`,
          flexShrink: 0,
          fontSize: "0.7rem",
          color: theme.sub,
        }}
      >
        <p style={{ margin: 0, marginBottom: "0.3rem" }}>Contexto:</p>
        <p
          style={{
            margin: 0,
            color: theme.accent,
            fontSize: "0.75rem",
            fontWeight: "500",
            wordBreak: "break-all",
            opacity: 0.8,
          }}
        >
          {fullPath}
        </p>
      </div>

      {/* Breadcrumb */}
      <div
        style={{
          padding: "0.6rem 0.9rem",
          borderBottom: `1px solid ${theme.accent}22`,
          display: "flex",
          alignItems: "center",
          gap: "0.4rem",
          flexWrap: "wrap",
          background: `${theme.bg}cc`,
          flexShrink: 0,
        }}
      >
        <span
          onClick={handleRootClick}
          onMouseDown={() => handleLongPressStart("/")}
          onMouseUp={handleLongPressEnd}
          onTouchStart={() => handleLongPressStart("/")}
          onTouchEnd={handleLongPressEnd}
          style={{
            color: path.length === 0 ? theme.text : theme.accent,
            cursor: "pointer",
            fontSize: "0.72rem",
            fontWeight: path.length === 0 ? "600" : "400",
            transition: "color 0.15s",
            userSelect: "none",
          }}
          title="Long-press para cambiar contexto raíz"
        >
          ~
        </span>
        {path.map((p, i) => (
          <span key={i} style={{ display: "flex", alignItems: "center", gap: "0.3rem" }}>
            <span style={{ color: theme.sub, fontSize: "0.65rem" }}>/</span>
            <span
              onClick={() => handleBreadcrumbClick(i)}
              onMouseDown={() => handleLongPressStart("/" + path.slice(0, i + 1).join("/"))}
              onMouseUp={handleLongPressEnd}
              onTouchStart={() => handleLongPressStart("/" + path.slice(0, i + 1).join("/"))}
              onTouchEnd={handleLongPressEnd}
              style={{
                color: i === path.length - 1 ? theme.text : theme.accent,
                cursor: "pointer",
                fontSize: "0.72rem",
                fontWeight: i === path.length - 1 ? "600" : "400",
                transition: "color 0.15s",
                userSelect: "none",
              }}
              title="Long-press para cambiar contexto raíz"
            >
              {p}
            </span>
          </span>
        ))}
      </div>

      {/* Contenido */}
      <div style={{ flex: 1, overflowY: "auto", padding: "0.4rem 0" }}>
        {isLoading && (
          <div style={{ padding: "2rem", textAlign: "center", color: theme.sub, fontSize: "0.75rem", opacity: 0.5 }}>
            cargando...
          </div>
        )}

        {error && (
          <div
            style={{
              padding: "1rem",
              margin: "0.5rem",
              borderRadius: "6px",
              background: "#ff6b6b30",
              border: "1px solid #ff6b6b44",
              color: "#ff6b6b",
              fontSize: "0.7rem",
            }}
          >
            Error: {error}
          </div>
        )}

        {!isLoading && !error && mockFiles.length === 0 && (
          <div style={{ padding: "2rem", textAlign: "center", color: theme.sub, fontSize: "0.75rem", opacity: 0.5 }}>
            carpeta vacía
          </div>
        )}

        {!isLoading && !error && mockFiles.length > 0 && (
          <div>
            {mockFiles.map((item) => {
              const isFolder = item.type === "folder";
              const isExpanded = expanded.has(item.path);
              const isSelected = selected === item.path;

              return (
                <div key={item.path}>
                  <div
                    onClick={() => {
                      if (isFolder) {
                        handleFolderClick(item.name);
                      } else {
                        setSelected(item.path);
                      }
                    }}
                    onMouseDown={() => handleLongPressStart(item.path)}
                    onMouseUp={handleLongPressEnd}
                    onTouchStart={() => handleLongPressStart(item.path)}
                    onTouchEnd={handleLongPressEnd}
                    style={{
                      padding: "0.5rem 0.9rem",
                      display: "flex",
                      alignItems: "center",
                      gap: "0.4rem",
                      cursor: "pointer",
                      background: isSelected ? `${theme.accent}15` : "transparent",
                      borderLeft: isSelected ? `2px solid ${theme.accent}` : "2px solid transparent",
                      color: isSelected ? theme.accent : theme.text,
                      fontSize: "0.75rem",
                      transition: "all 0.1s",
                      userSelect: "none",
                    }}
                    title={isFolder ? "Long-press para cambiar contexto raíz" : ""}
                  >
                    {isFolder && (
                      <ChevronRight
                        size={14}
                        style={{
                          transform: isExpanded ? "rotate(90deg)" : "rotate(0deg)",
                          transition: "transform 0.2s",
                          flexShrink: 0,
                          cursor: "pointer",
                          opacity: 0.6,
                        }}
                        onClick={(e) => {
                          e.stopPropagation();
                          toggleExpanded(item.path);
                        }}
                      />
                    )}
                    {!isFolder && <ChevronRight size={14} style={{ opacity: 0, flexShrink: 0 }} />}

                    {isFolder ? (
                      <Folder size={14} style={{ flexShrink: 0, opacity: 0.7 }} />
                    ) : (
                      <File size={14} style={{ flexShrink: 0, opacity: 0.5 }} />
                    )}

                    <span style={{ flex: 1, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                      {item.name}
                    </span>
                  </div>

                  {/* Subcarpetas (simuladas) */}
                  {isFolder && isExpanded && (
                    <div style={{ paddingLeft: "1.2rem" }}>
                      <div
                        style={{
                          padding: "0.4rem 0.5rem",
                          color: theme.sub,
                          fontSize: "0.7rem",
                          opacity: 0.5,
                        }}
                      >
                        subcarpeta 1
                      </div>
                      <div
                        style={{
                          padding: "0.4rem 0.5rem",
                          color: theme.sub,
                          fontSize: "0.7rem",
                          opacity: 0.5,
                        }}
                      >
                        subcarpeta 2
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Footer */}
      <div
        style={{
          padding: "0.4rem 0.9rem",
          borderTop: `1px solid ${theme.accent}15`,
          fontSize: "0.6rem",
          color: theme.sub,
          opacity: 0.5,
          flexShrink: 0,
        }}
      >
        {mockFiles.length} elementos
      </div>
    </div>
  );
}
