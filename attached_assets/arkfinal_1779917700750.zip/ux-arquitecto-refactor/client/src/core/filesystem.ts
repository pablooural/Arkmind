/**
 * Filesystem Abstraction Layer
 * Interfaz desacoplada para operaciones de archivo
 * 
 * CAMBIOS CAPA 1:
 * - FileSystemResult, FileSystemOperation, SUPPORTED_FORMATS movidos a tipos locales
 * - Estos tipos se definen aquí y se exportan solo FileSystemResult si es necesario
 * - API pública sin cambios
 */

import { FileNode } from "./types";
import { transactionManager } from "./transactions";

// ============ TIPOS LOCALES ============

export interface FileSystemResult {
  success: boolean;
  path: string;
  size?: number;
  content?: string;
  error?: string;
}

interface FileSystemOperation {
  id: string;
  type: "read" | "write" | "delete" | "create" | "move" | "copy";
  sourcePath: string;
  targetPath?: string;
  content?: string;
  options?: Record<string, any>;
}

const SUPPORTED_FORMATS = {
  text: ["txt", "md"],
  code: ["ts", "tsx", "js", "jsx", "json"],
  data: ["json", "yaml", "yml"],
} as const;

// ============ MANAGER ============

export class FilesystemManager {
  /**
   * Leer archivo
   */
  async readFile(path: string): Promise<FileSystemResult> {
    try {
      // TODO: Implementar lectura real
      return {
        success: true,
        path,
        content: "",
      };
    } catch (error) {
      return {
        success: false,
        path,
        error: String(error),
      };
    }
  }

  /**
   * Escribir archivo (con transacción)
   */
  async writeFile(path: string, content: string): Promise<FileSystemResult> {
    try {
      // 1. Validar formato
      if (!this.isSupportedFormat(path)) {
        return {
          success: false,
          path,
          error: `Unsupported file format: ${this.getExtension(path)}`,
        };
      }

      // 2. Crear transacción
      const transaction = await transactionManager.createTransaction("write", path);

      // 3. Simular
      const simulation = await transactionManager.simulateTransaction(transaction.id);
      if (!simulation.success) {
        return {
          success: false,
          path,
          error: `Simulation failed: ${simulation.errors.join(", ")}`,
        };
      }

      // 4. Ejecutar
      const executed = await transactionManager.executeTransaction(transaction.id);
      if (!executed) {
        return {
          success: false,
          path,
          error: "Execution failed",
        };
      }

      // 5. Confirmar
      transactionManager.confirmTransaction(transaction.id);

      return {
        success: true,
        path,
        size: content.length,
      };
    } catch (error) {
      return {
        success: false,
        path,
        error: String(error),
      };
    }
  }

  /**
   * Crear carpeta
   */
  async createFolder(path: string): Promise<FileSystemResult> {
    try {
      // TODO: Implementar creación de carpeta
      return {
        success: true,
        path,
      };
    } catch (error) {
      return {
        success: false,
        path,
        error: String(error),
      };
    }
  }

  /**
   * Eliminar archivo (con transacción)
   */
  async deleteFile(path: string): Promise<FileSystemResult> {
    try {
      // 1. Crear transacción
      const transaction = await transactionManager.createTransaction("delete", path);

      // 2. Simular
      const simulation = await transactionManager.simulateTransaction(transaction.id);
      if (!simulation.success) {
        return {
          success: false,
          path,
          error: `Simulation failed: ${simulation.errors.join(", ")}`,
        };
      }

      // 3. Ejecutar
      const executed = await transactionManager.executeTransaction(transaction.id);
      if (!executed) {
        return {
          success: false,
          path,
          error: "Execution failed",
        };
      }

      // 4. Confirmar
      transactionManager.confirmTransaction(transaction.id);

      return {
        success: true,
        path,
      };
    } catch (error) {
      return {
        success: false,
        path,
        error: String(error),
      };
    }
  }

  /**
   * Mover/Renombrar archivo
   */
  async moveFile(sourcePath: string, targetPath: string): Promise<FileSystemResult> {
    try {
      // TODO: Implementar movimiento de archivo
      return {
        success: true,
        path: targetPath,
      };
    } catch (error) {
      return {
        success: false,
        path: targetPath,
        error: String(error),
      };
    }
  }

  /**
   * Listar archivos en directorio
   */
  async listDirectory(path: string): Promise<FileNode[]> {
    try {
      // TODO: Implementar listado de directorio
      return [];
    } catch (error) {
      console.error(`Error listing directory ${path}:`, error);
      return [];
    }
  }

  /**
   * Obtener árbol de directorio recursivo
   */
  async getDirectoryTree(path: string, maxDepth: number = 10): Promise<FileNode | null> {
    try {
      // TODO: Implementar obtención de árbol
      return null;
    } catch (error) {
      console.error(`Error getting directory tree ${path}:`, error);
      return null;
    }
  }

  // ============ HELPERS ============

  private isSupportedFormat(filePath: string): boolean {
    const ext = this.getExtension(filePath);
    const allFormats: string[] = [];
    Object.values(SUPPORTED_FORMATS).forEach((formats) => {
      allFormats.push(...formats);
    });
    return allFormats.includes(ext);
  }

  private getExtension(filePath: string): string {
    const parts = filePath.split(".");
    return parts.length > 1 ? parts[parts.length - 1].toLowerCase() : "";
  }

  private generateOpId(): string {
    return `op_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }
}

export const filesystemManager = new FilesystemManager();
