/**
 * AI Integration Manager
 * Gestión de conexiones con APIs de IA (Mistral)
 * 
 * NUEVO:
 * - Soporte para 4 modelos Mistral (Large, Medium, Small, Pixtral)
 * - Integración con Supabase para persistencia
 * - Gestión de contexto y conversaciones
 */

import { StructuredMessage } from "./types";

export type MistralModel = "mistral-large" | "mistral-medium" | "mistral-small" | "pixtral-12b";

export interface AIConfig {
  provider: "mistral";
  model: MistralModel;
  apiKey: string;
  baseUrl?: string;
  temperature?: number;
  maxTokens?: number;
}

export interface SupabaseConfig {
  projectUrl: string;
  apiKey: string;
  enabled: boolean;
}

export interface AIMessage {
  role: "user" | "assistant";
  content: string;
}

const MISTRAL_MODELS: Record<MistralModel, { name: string; description: string }> = {
  "mistral-large": {
    name: "Mistral Large",
    description: "Modelo más potente, mejor para tareas complejas",
  },
  "mistral-medium": {
    name: "Mistral Medium",
    description: "Balance entre calidad y velocidad",
  },
  "mistral-small": {
    name: "Mistral Small",
    description: "Rápido y eficiente para tareas simples",
  },
  "pixtral-12b": {
    name: "Pixtral 12B",
    description: "Excelente rendimiento, multimodal",
  },
};

export class AIManager {
  private aiConfig: AIConfig | null = null;
  private supabaseConfig: SupabaseConfig | null = null;
  private conversationHistory: AIMessage[] = [];

  /**
   * Configurar AI (Mistral)
   */
  setAIConfig(config: AIConfig): void {
    this.aiConfig = config;
    console.log(`✓ AI configurado: ${config.model}`);
  }

  /**
   * Configurar Supabase
   */
  setSupabaseConfig(config: SupabaseConfig): void {
    this.supabaseConfig = config;
    console.log(`✓ Supabase configurado: ${config.projectUrl}`);
  }

  /**
   * Obtener configuración actual
   */
  getAIConfig(): AIConfig | null {
    return this.aiConfig;
  }

  getSupabaseConfig(): SupabaseConfig | null {
    return this.supabaseConfig;
  }

  /**
   * Obtener lista de modelos disponibles
   */
  getAvailableModels(): Array<{ id: MistralModel; name: string; description: string }> {
    return Object.entries(MISTRAL_MODELS).map(([id, info]) => ({
      id: id as MistralModel,
      ...info,
    }));
  }

  /**
   * Cambiar modelo activo
   */
  setModel(model: MistralModel): boolean {
    if (!this.aiConfig) return false;

    this.aiConfig.model = model;
    console.log(`✓ Modelo cambiado a: ${model}`);
    return true;
  }

  /**
   * Enviar mensaje a Mistral AI
   */
  async sendMessage(userMessage: string): Promise<string | null> {
    if (!this.aiConfig) {
      console.error("AI no configurado");
      return null;
    }

    try {
      // Agregar mensaje del usuario al historial
      this.conversationHistory.push({
        role: "user",
        content: userMessage,
      });

      // Llamar a Mistral API
      const response = await this.callMistralAPI(this.conversationHistory);

      if (response) {
        // Agregar respuesta al historial
        this.conversationHistory.push({
          role: "assistant",
          content: response,
        });

        // TODO: Guardar en Supabase si está habilitado
        if (this.supabaseConfig?.enabled) {
          await this.saveToDB(userMessage, response);
        }

        return response;
      }

      return null;
    } catch (error) {
      console.error("Error enviando mensaje a Mistral:", error);
      return null;
    }
  }

  /**
   * Llamar a Mistral API
   */
  private async callMistralAPI(messages: AIMessage[]): Promise<string | null> {
    if (!this.aiConfig) return null;

    try {
      const response = await fetch("https://api.mistral.ai/v1/chat/completions", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${this.aiConfig.apiKey}`,
        },
        body: JSON.stringify({
          model: this.aiConfig.model,
          messages: messages,
          temperature: this.aiConfig.temperature ?? 0.7,
          max_tokens: this.aiConfig.maxTokens ?? 1024,
        }),
      });

      if (!response.ok) {
        const error = await response.json();
        console.error("Mistral API error:", error);
        return null;
      }

      const data = await response.json();
      return data.choices?.[0]?.message?.content ?? null;
    } catch (error) {
      console.error("Error llamando a Mistral API:", error);
      return null;
    }
  }

  /**
   * Guardar conversación en Supabase
   */
  private async saveToDB(userMessage: string, assistantResponse: string): Promise<void> {
    if (!this.supabaseConfig?.enabled) return;

    try {
      // TODO: Implementar guardado en Supabase
      // const { data, error } = await supabase
      //   .from('conversations')
      //   .insert([
      //     {
      //       user_message: userMessage,
      //       assistant_response: assistantResponse,
      //       model: this.aiConfig?.model,
      //       created_at: new Date(),
      //     }
      //   ]);

      console.log("✓ Conversación guardada en Supabase");
    } catch (error) {
      console.error("Error guardando en Supabase:", error);
    }
  }

  /**
   * Obtener historial de conversación
   */
  getConversationHistory(): AIMessage[] {
    return [...this.conversationHistory];
  }

  /**
   * Limpiar historial
   */
  clearHistory(): void {
    this.conversationHistory = [];
    console.log("✓ Historial limpiado");
  }

  /**
   * Validar configuración
   */
  isConfigured(): boolean {
    return !!this.aiConfig && !!this.aiConfig.apiKey;
  }
}

export const aiManager = new AIManager();
