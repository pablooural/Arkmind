/**
 * UX Arquitecto - Core Types
 * 
 * Tipos fundamentales del Workspace Engine.
 * Diseñados para desacoplamiento fuerte entre Visual, Cognitivo y Sesiones.
 */

export type CognitiveGoal =
  | "architecture"
  | "refactor"
  | "debug"
  | "exploration"
  | "generation"
  | "review"
  | "planning"
  | "optimization";

export interface Insight {
  id: string;
  content: string;
  relatedFiles?: string[];
  importance: 1 | 2 | 3 | 4 | 5;
  createdAt: number;
  resolved?: boolean;
}

export interface Question {
  id: string;
  content: string;
  relatedFiles?: string[];
  priority: 1 | 2 | 3 | 4 | 5;
  createdAt: number;
  answered?: boolean;
}

export interface CognitiveContext {
  contextPath: string;
  goal: CognitiveGoal;
  focusSummary: string;
  insights: Insight[];
  openQuestions: Question[];
  constraints: string[];
  lastUpdated: number;
}

/** Estado visual persistente (restaurable) */
export interface PersistentVisualState {
  openFiles: string[];
  activeFile?: string;
  viewMode: "code" | "preview" | "split" | "diff";
}

/** Estado visual efímero (no se persiste en snapshots) */
export interface TransientVisualState {
  scrollPosition?: { x: number; y: number };
  selection?: {
    file: string;
    startLine: number;
    endLine: number;
  };
  lastInteraction: number;
}

export interface VisualContext {
  panelId: string;
  contextPath: string;
  persistent: PersistentVisualState;
  transient: TransientVisualState;
}

export type MessageType =
  | "text"
  | "code"
  | "diff"
  | "action"
  | "snapshot"
  | "proposal"
  | "warning";

export interface BaseMessage {
  id: string;
  role: "user" | "assistant" | "system";
  timestamp: number;
  metadata?: Record<string, any>;
}

export type StructuredMessage =
  | (BaseMessage & { type: "text"; content: string })
  | (BaseMessage & { type: "code"; language: string; content: string; path?: string })
  | (BaseMessage & { type: "diff"; before: string; after: string; path: string })
  | (BaseMessage & { type: "action"; action: string; payload: any })
  | (BaseMessage & { type: "snapshot"; snapshotId: string; description: string })
  | (BaseMessage & { type: "proposal"; proposalId: string; summary: string })
  | (BaseMessage & { type: "warning"; content: string; severity: "low" | "medium" | "high" });

export interface OperationProposal {
  id: string;
  type: "edit" | "create" | "delete" | "refactor" | "move";
  targetPath: string;
  description: string;
  changes?: any[]; // diff/patch
  status: "proposed" | "approved" | "rejected" | "executed";
  createdAt: number;
}

export type SessionState =
  | "active"
  | "idle"
  | "archived"
  | "forked"
  | "summarized"
  | "restoring";

export interface AIContextSession {
  id: string;
  panelId: string;
  contextPath: string;

  cognitiveContext: CognitiveContext;
  visualContextId?: string; // Referencia en vez de objeto completo

  messages: StructuredMessage[];
  proposals: OperationProposal[];

  lastSnapshotId?: string;
  state: SessionState;

  createdAt: number;
  lastActive: number;

  metadata: {
    forkOf?: string;
    version: number;
  };
}

export interface WorkspacePanel {
  id: string;
  type: "explorer" | "chat" | "editor" | "preview";
  contextPath: string;
  isActive: boolean;
  visualContext: VisualContext;
  sessionId?: string; // Referencia a AIContextSession
}

/** File system abstraction */
export interface FileNode {
  path: string;
  name: string;
  type: "file" | "directory";
  size?: number;
  modifiedAt?: number;
  children?: FileNode[];
  ext?: string;
}

/** Snapshot system */
export interface Snapshot {
  id: string;
  timestamp: number;
  label?: string;
  description?: string;
  contextPath: string;
  metadata: {
    filesCount: number;
    changedFiles: string[];
    totalSize?: number;
  };
  storePath: string; // dónde se guarda físicamente
}

/** Transaction system */
export interface Transaction {
  id: string;
  type: "read" | "write" | "delete" | "move" | "create";
  targetPath: string;
  snapshotId?: string;
  status: "pending" | "validated" | "executed" | "confirmed" | "rolled_back";
  createdAt: number;
  executedAt?: number;
}

/** Main Workspace */
export interface Workspace {
  id: string;
  name: string;
  rootPath: string;
  activeContextPath: string;
  panels: WorkspacePanel[];
  openSessions: Map<string, AIContextSession>; // panelId -> session
  createdAt: number;
  updatedAt: number;
}

// Utility types
export type ContextRelationship = {
  type: "parent" | "child" | "fork" | "reference" | "dependsOn";
  from: string;
  to: string;
  metadata?: Record<string, any>;
};

export interface WorkspaceEvent {
  type: string;
  payload: any;
  timestamp: number;
  source?: string;
}
