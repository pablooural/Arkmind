/**
 * Visual Context Manager
 * Gestión de contextos visuales por panel
 * 
 * NUEVO en Arkitectgr:
 * - Separa estado persistente (se guarda) de efímero (no se guarda)
 * - PersistentVisualState: openFiles, activeFile, viewMode
 * - TransientVisualState: scrollPosition, selection (solo en memoria)
 */

import { VisualContext, PersistentVisualState, TransientVisualState } from "./types";

export class VisualContextManager {
  private contexts: Map<string, VisualContext> = new Map();

  /**
   * Crear contexto visual para un panel
   */
  createContext(panelId: string, contextPath: string): VisualContext {
    const context: VisualContext = {
      panelId,
      contextPath,
      persistent: {
        openFiles: [],
        viewMode: "code",
      },
      transient: {
        lastInteraction: Date.now(),
      },
    };

    this.contexts.set(panelId, context);
    return context;
  }

  /**
   * Obtener contexto visual
   */
  getContext(panelId: string): VisualContext | undefined {
    return this.contexts.get(panelId);
  }

  /**
   * Actualizar estado persistente (se guarda en snapshots)
   */
  updatePersistent(
    panelId: string,
    updates: Partial<PersistentVisualState>
  ): boolean {
    const context = this.getContext(panelId);
    if (!context) return false;

    Object.assign(context.persistent, updates);
    context.transient.lastInteraction = Date.now();

    return true;
  }

  /**
   * Actualizar estado efímero (no se guarda)
   */
  updateTransient(panelId: string, updates: Partial<TransientVisualState>): boolean {
    const context = this.getContext(panelId);
    if (!context) return false;

    Object.assign(context.transient, updates);
    context.transient.lastInteraction = Date.now();

    return true;
  }

  /**
   * Abrir archivo en panel
   */
  openFile(panelId: string, filePath: string): boolean {
    const context = this.getContext(panelId);
    if (!context) return false;

    if (!context.persistent.openFiles.includes(filePath)) {
      context.persistent.openFiles.push(filePath);
    }

    context.persistent.activeFile = filePath;
    context.transient.lastInteraction = Date.now();

    return true;
  }

  /**
   * Cerrar archivo en panel
   */
  closeFile(panelId: string, filePath: string): boolean {
    const context = this.getContext(panelId);
    if (!context) return false;

    const index = context.persistent.openFiles.indexOf(filePath);
    if (index === -1) return false;

    context.persistent.openFiles.splice(index, 1);

    // Si era el archivo activo, cambiar a otro
    if (context.persistent.activeFile === filePath) {
      context.persistent.activeFile = context.persistent.openFiles[0];
    }

    context.transient.lastInteraction = Date.now();

    return true;
  }

  /**
   * Establecer archivo activo
   */
  setActiveFile(panelId: string, filePath: string): boolean {
    const context = this.getContext(panelId);
    if (!context) return false;

    // Asegurar que el archivo esté abierto
    if (!context.persistent.openFiles.includes(filePath)) {
      context.persistent.openFiles.push(filePath);
    }

    context.persistent.activeFile = filePath;
    context.transient.lastInteraction = Date.now();

    return true;
  }

  /**
   * Cambiar modo de vista
   */
  setViewMode(
    panelId: string,
    mode: "code" | "preview" | "split" | "diff"
  ): boolean {
    const context = this.getContext(panelId);
    if (!context) return false;

    context.persistent.viewMode = mode;
    context.transient.lastInteraction = Date.now();

    return true;
  }

  /**
   * Establecer posición de scroll
   */
  setScrollPosition(panelId: string, x: number, y: number): boolean {
    const context = this.getContext(panelId);
    if (!context) return false;

    context.transient.scrollPosition = { x, y };
    context.transient.lastInteraction = Date.now();

    return true;
  }

  /**
   * Establecer selección de texto
   */
  setSelection(
    panelId: string,
    file: string,
    startLine: number,
    endLine: number
  ): boolean {
    const context = this.getContext(panelId);
    if (!context) return false;

    context.transient.selection = {
      file,
      startLine,
      endLine,
    };
    context.transient.lastInteraction = Date.now();

    return true;
  }

  /**
   * Obtener estado persistente (para snapshots)
   */
  getPersistentState(panelId: string): PersistentVisualState | undefined {
    const context = this.getContext(panelId);
    return context?.persistent;
  }

  /**
   * Obtener estado efímero
   */
  getTransientState(panelId: string): TransientVisualState | undefined {
    const context = this.getContext(panelId);
    return context?.transient;
  }

  /**
   * Restaurar estado persistente (desde snapshot)
   */
  restorePersistentState(panelId: string, state: PersistentVisualState): boolean {
    const context = this.getContext(panelId);
    if (!context) return false;

    context.persistent = { ...state };
    context.transient.lastInteraction = Date.now();

    return true;
  }

  /**
   * Limpiar contexto visual
   */
  clearContext(panelId: string): boolean {
    return this.contexts.delete(panelId);
  }

  /**
   * Obtener todos los contextos visuales
   */
  getAllContexts(): VisualContext[] {
    const contexts: VisualContext[] = [];
    this.contexts.forEach((context) => {
      contexts.push(context);
    });
    return contexts;
  }
}

export const visualManager = new VisualContextManager();
