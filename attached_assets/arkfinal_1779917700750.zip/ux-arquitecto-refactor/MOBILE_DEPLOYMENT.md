# Acceso desde Cualquier Teléfono - Guía de Deployment

**Fecha**: 27 de Mayo de 2026  
**Versión**: Arkitectgr v2.4 - Mobile Ready  
**Estado**: ✓ Listo para deploy

---

## Resumen

La webapp está lista para acceder desde cualquier teléfono. Solo necesitas:

1. **Crear las tablas en Supabase** (user, projects, conversations, messages, snapshots)
2. **Deployar la webapp** (Manus, Vercel, Railway, etc.)
3. **Acceder desde cualquier dispositivo** con el enlace público

---

## Paso 1: Crear Tablas en Supabase

Abre https://app.supabase.com y ve a **SQL Editor**. Copia y pega esto:

```sql
-- Tabla de usuarios
CREATE TABLE users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email VARCHAR(255) NOT NULL UNIQUE,
  name VARCHAR(255),
  created_at TIMESTAMP DEFAULT NOW(),
  confirmed_at TIMESTAMP,
  last_login TIMESTAMP,
  is_active BOOLEAN DEFAULT true
);

-- Tabla de proyectos
CREATE TABLE projects (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  name VARCHAR(255) NOT NULL,
  description TEXT,
  root_path VARCHAR(1024),
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW(),
  is_archived BOOLEAN DEFAULT false
);

-- Tabla de conversaciones
CREATE TABLE conversations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id UUID NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  node_path VARCHAR(1024) NOT NULL,
  goal VARCHAR(50),
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

-- Tabla de mensajes
CREATE TABLE messages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  conversation_id UUID NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
  role VARCHAR(20) NOT NULL,
  content TEXT NOT NULL,
  message_type VARCHAR(50),
  created_at TIMESTAMP DEFAULT NOW()
);

-- Tabla de snapshots
CREATE TABLE snapshots (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id UUID NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
  workspace_state JSONB NOT NULL,
  total_size BIGINT,
  created_at TIMESTAMP DEFAULT NOW(),
  description TEXT
);

-- Índices para mejor rendimiento
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_projects_user_id ON projects(user_id);
CREATE INDEX idx_conversations_project_id ON conversations(project_id);
CREATE INDEX idx_messages_conversation_id ON messages(conversation_id);
CREATE INDEX idx_snapshots_project_id ON snapshots(project_id);
```

Ejecuta el script. ✓ Tablas creadas.

---

## Paso 2: Configurar Variables de Entorno

Las siguientes variables ya están configuradas en el servidor:

```
SUPABASE_URL=https://mkrliicvotzlmsycyuak.supabase.co
SUPABASE_API_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
MISTRAL_API_KEY=ndxsa1r3XoXSnmZOZ9Rx3K5adn9oBaZR
```

Si deployas en otro lugar, asegúrate de configurar estas variables.

---

## Paso 3: Endpoints Disponibles

### Autenticación

**POST /api/auth/send-confirmation**
```bash
curl -X POST http://localhost:3000/api/auth/send-confirmation \
  -H "Content-Type: application/json" \
  -d '{"email": "usuario@email.com"}'
```

**POST /api/auth/confirm-email**
```bash
curl -X POST http://localhost:3000/api/auth/confirm-email \
  -H "Content-Type: application/json" \
  -d '{"token": "abc123..."}'
```

### Proyectos

**GET /api/projects** - Obtener todos los proyectos
```bash
curl -X GET http://localhost:3000/api/projects \
  -H "x-user-id: user_123"
```

**POST /api/projects** - Crear nuevo proyecto
```bash
curl -X POST http://localhost:3000/api/projects \
  -H "Content-Type: application/json" \
  -H "x-user-id: user_123" \
  -d '{
    "name": "Mi Proyecto",
    "description": "Descripción",
    "root_path": "/home/user/projects"
  }'
```

**GET /api/projects/:id** - Obtener un proyecto
```bash
curl -X GET http://localhost:3000/api/projects/project_123 \
  -H "x-user-id: user_123"
```

**PUT /api/projects/:id** - Actualizar proyecto
```bash
curl -X PUT http://localhost:3000/api/projects/project_123 \
  -H "Content-Type: application/json" \
  -H "x-user-id: user_123" \
  -d '{"name": "Nuevo Nombre"}'
```

**DELETE /api/projects/:id** - Archivar proyecto
```bash
curl -X DELETE http://localhost:3000/api/projects/project_123 \
  -H "x-user-id: user_123"
```

### Conversaciones

**GET /api/conversations/:projectId** - Obtener conversaciones del proyecto
```bash
curl -X GET http://localhost:3000/api/conversations/project_123 \
  -H "x-user-id: user_123"
```

**POST /api/conversations/:projectId** - Crear conversación
```bash
curl -X POST http://localhost:3000/api/conversations/project_123 \
  -H "Content-Type: application/json" \
  -H "x-user-id: user_123" \
  -d '{
    "node_path": "/src/components/Button.tsx",
    "goal": "refactor"
  }'
```

**GET /api/conversations/:conversationId/messages** - Obtener mensajes
```bash
curl -X GET http://localhost:3000/api/conversations/conv_123/messages \
  -H "x-user-id: user_123"
```

**POST /api/conversations/:conversationId/messages** - Agregar mensaje
```bash
curl -X POST http://localhost:3000/api/conversations/conv_123/messages \
  -H "Content-Type: application/json" \
  -H "x-user-id: user_123" \
  -d '{
    "role": "user",
    "content": "Refactoriza este componente",
    "message_type": "text"
  }'
```

---

## Paso 4: Acceder desde Teléfono

### Opción A: Manus (Recomendado)

1. Abre la Management UI
2. Haz clic en **Publish**
3. Obtienes un enlace público: `https://xxx.manus.space`
4. Abre en tu teléfono

### Opción B: Vercel

```bash
# Instalar Vercel CLI
npm i -g vercel

# Deployar
vercel --prod
```

Obtienes: `https://xxx.vercel.app`

### Opción C: Railway

1. Conecta tu repositorio GitHub
2. Configura variables de entorno
3. Deploy automático

### Opción D: Localhost en Red Local

```bash
# Obtener IP local
ifconfig | grep "inet " | grep -v 127.0.0.1

# Acceder desde teléfono
http://192.168.1.100:3000
```

---

## Paso 5: Flujo de Usuario en Teléfono

```
1. Abre la app en teléfono
   ↓
2. Ingresa email
   ↓
3. Recibe email de confirmación
   ↓
4. Hace clic en enlace
   ↓
5. Queda logueado
   ↓
6. Ve panel de chat (izquierda)
   ↓
7. Ve explorador de archivos (derecha, deslizable)
   ↓
8. Puede cambiar tema con botón ≡
   ↓
9. Puede crear proyectos
   ↓
10. Puede tener conversaciones por nodo
```

---

## Características Mobile

✓ **Responsive Design** - Se adapta a cualquier tamaño de pantalla  
✓ **Touch-Friendly** - Botones grandes, sin hover  
✓ **Panel Deslizable** - Swipe para abrir/cerrar explorador  
✓ **Tema Personalizable** - 5 paletas de color  
✓ **Offline Ready** - Sesión se guarda en localStorage  
✓ **Rápido** - Vite + React optimizado  

---

## Troubleshooting

### "No se conecta a Supabase"

1. Verifica que las tablas existan en Supabase
2. Verifica que SUPABASE_URL y SUPABASE_API_KEY están configurados
3. Verifica que la API Key tiene permisos en Supabase

### "Error en email de confirmación"

1. Por ahora, el email se simula en desarrollo
2. Para producción, necesitas integrar Resend o SendGrid
3. TODO: Agregar integración de email real

### "No puedo acceder desde teléfono"

1. Verifica que la app está deployada públicamente
2. Verifica que el teléfono está en la misma red (si es localhost)
3. Verifica que el firewall permite conexiones

### "Sesión se cierra al recargar"

1. Verifica que localStorage está habilitado
2. Verifica que el token no ha expirado (30 días)
3. Limpia cache del navegador

---

## Próximos Pasos

1. **Integrar email real** - SendGrid o Resend
2. **Agregar autenticación JWT** - Para proteger endpoints
3. **Implementar rate limiting** - Prevenir abuso
4. **Agregar logging** - Rastrear errores
5. **Crear dashboard de admin** - Ver usuarios y proyectos

---

**Fin de la Guía de Mobile Deployment**
